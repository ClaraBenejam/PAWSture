from django.db import IntegrityError
from django.core.exceptions import ObjectDoesNotExist
from django.db.models import Max, Min, Avg

from .models import Granja
from sensores.models import Sensor
from django.contrib.auth.models import User, Group 
import random
import string

from typing import Union

LONG_ID = 12

class GestorGranjas:
    def registrarGranja(nomOperador : str, mote : str, password: str ) -> dict:
        try:
            idGranja = ''.join(  random.choice( string.ascii_letters) for i in range(LONG_ID))
            Granja.objects.get(idGranja=idGranja)
            res = {'code': 2}
        except ObjectDoesNotExist:
            granja = Granja(idGranja=idGranja, mote=mote, nomOperador=nomOperador)
            try:
                usuario = User.objects.create_user(username=nomOperador, password=password) 
                grupo = Group.objects.get(name="granjeros") 
                usuario.groups.add(grupo) 
                usuario.save() 
            except IntegrityError:
                res = {'code': 3}
            try:                
                granja.save()
                res = {'code': 0}
            except IntegrityError:
                res = {'code': 1}
        return res
    

    def buscarGranja(nombre: str) -> Union[list, Granja, None]:
        try:
            operador = User.objects.get(username = nombre)
            grupo=operador.groups.get()
            grupo2 = Group.objects.get(name="granjeros") 
            if (grupo == grupo2):
                granja = Granja.objects.filter(nomOperador = nombre)
                return granja
            else:
                granjas = list( Granja.objects.all())
                return granjas
            pass
        except ObjectDoesNotExist:
            return None
            pass
        pass
        

    def encontrarGranja(idGranja : str = None) -> Union[list, Granja, None]:
        if ( idGranja is None ):
            granjas = list( Granja.objects.all())
            return granjas
            pass
        else:
            try:
                granja = Granja.objects.get(idGranja = idGranja)
                return granja
                pass
            except ObjectDoesNotExist:
                return None
                pass
            pass
        pass    


    def mostrarGranja( idGranja : str = None ) -> Union[list, Granja, None]:
        try:
            granja = Granja.objects.get(idGranja = idGranja)
            sensores = Sensor.objects.filter(GranjaidGranja = granja).order_by('-mote')
            humedadMax = sensores.aggregate(Max('humedad'))
            humedadMin = sensores.aggregate(Min('humedad'))
            humedadAvg = sensores.aggregate(Avg('humedad'))
            return granja,sensores, humedadMax, humedadMin, humedadAvg
            pass
        except ObjectDoesNotExist:
            return None
            pass
        

    def borrarGranja( idGranja : str ) -> Union[ Granja, None]:
        if ( idGranja is None ):
            return None
        
        try:
            granja = Granja.objects.get( idGranja = idGranja)
            granja.delete()
            return granja
            pass
        except ObjectDoesNotExist:
            return None
            pass
        pass
    pass

    def registrarSensorGranja(idGranja : str, mote : str ) -> dict:
        try:
            granja=Granja.objects.get(idGranja=idGranja)
            Sensor.objects.get( mote = mote)
            sensor = Sensor.objects.get( mote = mote)
            if (sensor.GranjaidGranja == granja):
                res = {'code': 1}
            else:
                sensor.GranjaidGranja = granja
                sensor.save()
                res = {'code': 0}
        except ObjectDoesNotExist:
            res = {'code': 2}
        return res
    

    def desinstalarSensor( idSensor : str ) -> Union[ Sensor, None]:
        if ( idSensor is None ):
            return None
        
        try:
            sensor = Sensor.objects.get(idSensor = idSensor)
            sensor.GranjaidGranja = None
            sensor.save()
            return sensor
            pass
        except ObjectDoesNotExist:
            return None
            pass
        pass
    pass