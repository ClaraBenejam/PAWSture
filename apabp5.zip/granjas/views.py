from django.shortcuts import render
from django.urls import reverse
from granjas.forms import RegGranja, FormSensorGranja
from granjas.granjasMgr import GestorGranjas
from django.contrib.auth.decorators import permission_required
from django.http import HttpResponse, HttpRequest


# Create your views here.

REG_GRANJA = 'granjas/regGranja.html'
REG_SENSOR_GRANJA = 'granjas/regSensorGranja.html'
MOSTRAR_GRANJA = 'granjas/mostrarGranja.html'
LISTA_GRANJAS = 'granjas/listaGranjas.html'
RESULTADO = 'info/res.html'

@permission_required(['granjas.add_granja', 'auth.add_user'], raise_exception=True)
def formRegGranja(request : HttpRequest ) -> HttpResponse: 
    if ((request.method != 'GET') and (request.method != 'POST')): 
        error = "Operación de protocolo empleada incorrecta. Fallo en el navegador" 
        op = "Registro de una nueva granja" 
        return render(request, RESULTADO, {'errorMsg': error, "texto_op" : op }) 
        pass 
 
    if (request.method == 'GET'): 
        form = RegGranja() 
        return render(request, REG_GRANJA, {'formulario': form }) 
        pass 
 
    if (request.method == 'POST'): 
        form = RegGranja(request.POST) 
        if (form.is_valid()): 
            nomOperador = form.cleaned_data['nomOperador'] 
            mote = form.cleaned_data['mote'] 
            password = form.cleaned_data['password'] 
            res = GestorGranjas.registrarGranja(nomOperador, mote, password) 
            if (res['code'] == 0): 
                texto = "La granja \'"+mote+"\' añadida correctamente" 
                op = "Registro de una nueva granja" 
                return render(request, RESULTADO, {'texto': texto, 
                      "texto_op" : op, 'url_volver': reverse('registrar-granja') }) 
                pass 
            else: 
                error = "Error" 
                if (res['code'] == 1): 
                    error = 'Ya hay una granja con mote \''+mote+'\' o con operador \''+nomOperador+'\'' 
                    pass 
                if (res['code'] == 2): 
                    error = 'Ya existe la granja con mote: '+mote 
                    pass 
                if (res['code'] == 3): 
                    error = 'No se ha podido crear un nuevo usuario: '+mote 
                    pass 
                return render(request, REG_GRANJA, {'formulario': form, 'errorMsg': error}) 
                pass 
            pass 
        else: 
            error="Error en el formulario" 
            return render(request, REG_GRANJA, {'formulario': form, 'errorMsg': error})
        
@permission_required(['granjas.view_granja'], raise_exception=True)
def  mostrarGranjas( request : HttpRequest ) -> HttpResponse:
    if (request.method == 'GET'):
        lista = GestorGranjas.buscarGranja(request.user.get_username())
        return render(request, LISTA_GRANJAS, {'lista': lista})
        pass

    error = "Operación de protocolo empleada incorrecta. Fallo en el navegador"
    op = "Búsqueda de granjas"
    return render(request, RESULTADO, {'errorMsg': error, "texto_op" : op }, status=405)
    pass

@permission_required(['granjas.delete_granja', 'auth.delete_user','sensores.change_sensor'], raise_exception=True)
def borrarGranja(request : HttpRequest, idGranja : str ) -> HttpResponse:
    if ( request.method == 'DELETE'):
        res = GestorGranjas.borrarGranja(idGranja)
        if ( res is None):
            error = "No existe la granja con identificador " + idGranja
            op = "Eliminar granja"
            return render(request, RESULTADO, {'errorMsg': error, "texto_op" : op, "url_volver" : reverse('ver-granjas') })
            pass
        else:
            texto = "La granja \'" + idGranja + "\' ha sido borrada."
            op = "Eliminar granja"
            return render(request, RESULTADO, {'texto': texto, "texto_op" : op, "url_volver" : reverse('ver-granjas') })
            pass
        pass
    error = "Operación de protocolo empleada incorrecta. Fallo en el navegador"
    op = "Eliminar granja"
    return render(request, RESULTADO, {'errorMsg': error, "texto_op" : op, "url_volver" : reverse('ver-granjas') }, status=405)
    pass

@permission_required(['sensores.change_sensor'], raise_exception=True)
def desinstalarSensor(request : HttpRequest, idSensor : str ) -> HttpResponse:
    if ( request.method == 'DELETE'):
        res = GestorGranjas.desinstalarSensor(idSensor)
        if ( res is None):
            error = "No existe el sensor con identificador " + idSensor
            op = "Desinstalar sensor"
            return render(request, RESULTADO, {'errorMsg': error, "texto_op" : op, "url_volver" : reverse('ver-granjas') })
            pass
        else:
            texto = "El sensor \'" + idSensor + "\' ha sido desinstalado"
            op = "Desinstalar sensor"
            return render(request, RESULTADO, {'texto': texto, "texto_op" : op, "url_volver" : reverse('ver-granjas') })
            pass
        pass
    error = "Operación de protocolo empleada incorrecta. Fallo en el navegador"
    op = "Eliminar granja"
    return render(request, RESULTADO, {'errorMsg': error, "texto_op" : op, "url_volver" : reverse('ver-granjas') }, status=405)
    pass
@permission_required(['granjas.view_granja'], raise_exception=True)
def mostrarGranja( request : HttpRequest, idGranja : str ) -> HttpResponse:
    if (request.method == 'GET'):
        res = GestorGranjas.mostrarGranja(idGranja)
        if ( res is None):
            error = "No existe la granja con identificador " + idGranja
            op = "Buscar granja"
            return render(request, RESULTADO, {'errorMsg': error, "texto_op" : op, "url_volver" : reverse('ver-granjas') })
            pass
        else:
            return render(request, MOSTRAR_GRANJA, {'granja': res[0], "sensores":res[1], "humedadMax":res[2], "humedadMin":res[3], "humedadMean":res[4], "url_volver" : reverse('ver-granjas') })
            pass
    error = "Operación de protocolo empleada incorrecta. Fallo en el navegador"
    op = "Mostrar granja"
    return render(request, RESULTADO, {'errorMsg': error, "texto_op" : op, "url_volver" : reverse('ver-granjas') }, status=405)
    pass

@permission_required(['sensores.change_sensor'], raise_exception=True)
def RegSensorGranja(request : HttpRequest, idGranja : str ) -> HttpResponse:

    if ((request.method != 'GET') and (request.method != 'POST')):
        error = "Operación de protocolo empleada incorrecta. Fallo en el navegador"
        op = "Registro de una nueva granja"
        return render(request, RESULTADO, {'errorMsg': error, "texto_op" : op }, status=405)
        pass
    
    if (request.method == 'GET'):
        form = FormSensorGranja()
        res = GestorGranjas.encontrarGranja(idGranja)
        if ( res is None):
            error = "No existe la granja con identificador " + idGranja
            op = "Buscar granja"
            return render(request, RESULTADO, {'errorMsg': error, "texto_op" : op, "url_volver" : reverse('ver-granjas') })
            pass

        else:
            return render(request, REG_SENSOR_GRANJA, {'granja': res, 'formulario': form , "url_volver" : reverse('ver-granjas') })
            pass
        
    if (request.method == 'POST'):
        form = FormSensorGranja(request.POST)
        if (form.is_valid()):
            mote = form.cleaned_data['mote']
            res = GestorGranjas.registrarSensorGranja(idGranja, mote)
            if (res['code'] == 0):
                texto = "El sensor \'"+mote+"\' ha sido instalado correctamente en la granja con id: \'"+idGranja+"\'"
                op = "Instalación de un sensor en una granja"
                return render(request, RESULTADO, {'texto': texto, "texto_op" : op, 'url_volver': reverse('ver-granjas') })
                pass
            else:
                error = "Error"
                if (res['code'] == 1):
                    error = 'El sensor \''+mote+'\' ya está instalado en la granja con id:  \''+idGranja+'\''
                    op= "Error de instalación de sensor"
                    pass
                if (res['code'] == 2):
                    error = 'No existe el sensor: '+mote
                    op= "Error de instalación de sensor"
                    pass
                return render(request, RESULTADO, {'errorMsg': error,"texto_op":op, "url_volver" : reverse('ver-granjas') })
                pass
            pass
        else:
            error="Error en el formulario"
            op = "Instalación de un sensor en una granja"
            return render(request, REG_SENSOR_GRANJA, {'errorMsg': error, "texto_op" : op, "url_volver" : reverse('ver-granjas') })
            pass
    pass


