from django.db import models

class Granja( models.Model ):
    idGranja = models.CharField( max_length=20, primary_key=True)   # Clave primaria. Es el identificador único de la granja.
    mote = models.CharField( max_length=50, unique=True)            # Nombre amigable de la granja.
                                                                    # en la granja.
    nomOperador = models.CharField( max_length=20, unique=True)     # Nombre de usuario del operador de la granja.
    