

def contextoGranjas(request):
    return {'tabla_granja': 'granjas/tablaGranjas.html',
            'tabla_granja_sensor': 'granjas/tablaGranjaSensor.html'
            }


