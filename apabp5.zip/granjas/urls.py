from django.urls import path
from granjas import views
# Ver https://www.bookaapi.com/book-blogging/url-structure/

urlpatterns = [
    path('', views.mostrarGranjas, name='ver-granjas'),
    path('borrar/<str:idGranja>/', views.borrarGranja, name='borrar-granja'),
    path('desinstalar/<str:idSensor>/', views.desinstalarSensor, name='desinstalar-sensor'),
    path('mostrar/<str:idGranja>/', views.mostrarGranja, name='ver-granja'),
    path('formularios/registrar-granja/', views.formRegGranja, name='registrar-granja'),
    path('formularios/registrar-sensor-granja/<str:idGranja>', views.RegSensorGranja, name='registrar-sensor-granja')
]