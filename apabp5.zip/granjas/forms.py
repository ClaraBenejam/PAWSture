from django import forms

class RegGranja( forms.Form ):
    mote = forms.CharField( label='Nombre granja', max_length=50, required=True) 
    nomOperador = forms.CharField( label='Nombre de usuario del operador', 
                                   max_length=20, required=True) 
    password = forms.CharField( label='Contraseña', max_length=12, required=True, 
                                widget=forms.PasswordInput()) 
    pass 

class FormSensorGranja( forms.Form ):
    mote = forms.CharField( label='Nombre del sensor', max_length=50)
    pass