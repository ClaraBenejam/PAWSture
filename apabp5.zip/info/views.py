from django.shortcuts import render
from django.contrib.auth import authenticate, login, logout 
from django.template.exceptions import TemplateDoesNotExist
from django.http import Http404, HttpResponse, HttpRequest
from info.forms import LogInUsuarios
# Create your views here.
PATH = 'info/'
HOME = 'info/base.html'
INFO = 'info/apab-info-general.html'
NEWS = 'info/apab-noticias.html'
RES_SESION = 'info/res-sesion.html' 
LOGIN_USUARIOS='info/apab-login.html'
RESULTADO = 'info/res.html'


def home( request : HttpRequest ) -> HttpResponse:
    return render (request, HOME)

def info( request : HttpRequest ) -> HttpResponse:
    return render (request, INFO)

def get_html_file( request : HttpRequest, html_file : str ) -> HttpResponse:
    try:
        return render (request, PATH+html_file)
        pass
    except TemplateDoesNotExist as ex:
        raise Http404
        pass

def news( request : HttpRequest ) -> HttpResponse:
    return render(request, NEWS)
    pass

def logIn( request : HttpRequest) -> HttpResponse: 
    if ((request.method != 'GET') and (request.method != 'POST')): 
        error = "Incorrect protocol operation used. Browser failure"
        op = "Login" 
        return render(request, RESULTADO, {'errorMsg': error, "texto_op" : op }) 
        pass 
 
    if (request.method == 'GET'): 
        form = LogInUsuarios() 
        request.session.set_test_cookie() 
        return render(request, LOGIN_USUARIOS, {'formulario':form }) 
     
    if ( request.method == 'POST'): 
        form = LogInUsuarios(request.POST) 
        if request.session.test_cookie_worked(): 
            request.session.delete_test_cookie() 
        else: 
            error='Please, enable cookies to continue' 
            
            return render(request, LOGIN_USUARIOS, 
                          {'formulario':form, 'errorMsg':error }) 
        if ( form.is_valid()): 
            nombreUsuario = form.cleaned_data['username'] 
            contrasenya = form.cleaned_data['password'] 
            usuario = authenticate(request, 
                                   username=nombreUsuario, password=contrasenya) 
            if ( usuario ): 
                if ( request.user.is_authenticated ): 
                    logout(request) 
                login(request, usuario) 
                texto = "The login has been completed successfully" 
                op = "Login" 
                return render(request, RES_SESION, 
                                  {'texto': texto, "texto_op" : op}) 
            else: 
                error='Incorrect username or password' 
                request.session.set_test_cookie() 
                return render(request, LOGIN_USUARIOS, 
                                 {'formulario':form, 'errorMsg':error }) 
        else: 
            error="Some of the form fields contain incorrect data" 
            request.session.set_test_cookie() 
            return render(request, LOGIN_USUARIOS, 
                             {'formulario':form, 'errorMsg':error }) 
         
def logOut( request : HttpRequest) -> HttpResponse: 
    if ( request.method == 'POST'): 
        logout( request ) 
        texto = "The session has ended successfully" 
        op = "Log Out" 
        return render(request, RES_SESION, {'texto': texto, "texto_op" : op}) 
     
    error = "Incorrectly used protocol operation. Browser failure" 
    op = "Log Out" 
    return render(request, RESULTADO, {'errorMsg': error, "texto_op" : op })             

