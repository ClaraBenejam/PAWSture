from django.shortcuts import render
from django.contrib.auth import authenticate, login, logout 
from django.template.exceptions import TemplateDoesNotExist
from django.http import Http404, HttpResponse, HttpRequest
from info.forms import LogInUsuarios
# Create your views here.
PATH = 'info/'
HOME = 'info/base.html'
INFO = 'info/apab-info-general.html'
NEWS = 'info/apab-noticias.html'
RES_SESION = 'info/res-sesion.html' 
LOGIN_USUARIOS='info/apab-login.html'
RESULTADO = 'info/res.html'


def home( request : HttpRequest ) -> HttpResponse:
    return render (request, HOME)

def info( request : HttpRequest ) -> HttpResponse:
    return render (request, INFO)

def get_html_file( request : HttpRequest, html_file : str ) -> HttpResponse:
    try:
        return render (request, PATH+html_file)
        pass
    except TemplateDoesNotExist as ex:
        raise Http404
        pass

def news( request : HttpRequest ) -> HttpResponse:
    return render(request, NEWS)
    pass

def logIn( request : HttpRequest) -> HttpResponse: 
    if ((request.method != 'GET') and (request.method != 'POST')): 
        error = "Operación de protocolo empleada incorrecta. Fallo en el navegador" 
        op = "Inicio de sesión" 
        return render(request, RESULTADO, {'errorMsg': error, "texto_op" : op }) 
        pass 
 
    if (request.method == 'GET'): 
        form = LogInUsuarios() 
        request.session.set_test_cookie() 
        return render(request, LOGIN_USUARIOS, {'formulario':form }) 
     
    if ( request.method == 'POST'): 
        form = LogInUsuarios(request.POST) 
        if request.session.test_cookie_worked(): 
            request.session.delete_test_cookie() 
        else: 
            error='Por favor, habilite las cookies para continuar' 
            return render(request, LOGIN_USUARIOS, 
                          {'formulario':form, 'errorMsg':error }) 
        if ( form.is_valid()): 
            nombreUsuario = form.cleaned_data['username'] 
            contrasenya = form.cleaned_data['password'] 
            usuario = authenticate(request, 
                                   username=nombreUsuario, password=contrasenya) 
            if ( usuario ): 
                if ( request.user.is_authenticated ): 
                    logout(request) 
                login(request, usuario) 
                texto = "El inicio de sesión se ha completado satisfactoriamente" 
                op = "Inicio de sesión" 
                return render(request, RES_SESION, 
                                  {'texto': texto, "texto_op" : op}) 
            else: 
                error='Nombre de usuario o contraseña incorrectos' 
                request.session.set_test_cookie() 
                return render(request, LOGIN_USUARIOS, 
                                 {'formulario':form, 'errorMsg':error }) 
        else: 
            error="Los datos de algún campo del formulario son incorrectos" 
            request.session.set_test_cookie() 
            return render(request, LOGIN_USUARIOS, 
                             {'formulario':form, 'errorMsg':error }) 
         
def logOut( request : HttpRequest) -> HttpResponse: 
    if ( request.method == 'POST'): 
        logout( request ) 
        texto = "La sesión ha finalizado" 
        op = "Cierre de sesión" 
        return render(request, RES_SESION, {'texto': texto, "texto_op" : op}) 
     
    error = "Operación de protocolo empleada incorrecta. Fallo en el navegador" 
    op = "Cerrar sesión" 
    return render(request, RESULTADO, {'errorMsg': error, "texto_op" : op })             

