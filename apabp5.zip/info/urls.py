from django.urls import path
from info import views

# Ver https://www.bookaapi.com/book-blogging/url-structure/

urlpatterns = [
    path('', views.home, name='apab-inicio'),
    path('noticias/', views.news, name='apab-noticias'),
    path('info/', views.info, name='apab-info-general'),
    path('<str:html_file>', views.get_html_file, name='apab-html-file'),
    path('login/', views.logIn, name='apab-login'),
    path('logout/', views.logOut, name='apab-logout'),  
]