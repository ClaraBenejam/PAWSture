from django import forms

class LogInUsuarios( forms.Form):
    username = forms.CharField( label='user name', max_length=10, widget=forms.TextInput(attrs={'placeholder':'user name'}))
    password = forms.CharField( label='password', max_length=20, widget=forms.PasswordInput(attrs={'placeholder':'password'}))
