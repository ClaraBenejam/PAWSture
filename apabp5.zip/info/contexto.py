

def contextoInfo(request):
    return {'apab_inicio': 'info/base.html',
            'apab_imagen_granja_inteligente': 'info/granja-inteligente.png',
            'apab_favicon': 'info/logo-apab.png',
            'apab_logo':'info/logo-apab.png',
            'apab_smart_farming': 'info/smart-farming.jpeg',
            'apab_css': 'info/apab.css',
            'apab_anadir': 'info/anadir.png',
            'apab_enlace': 'info/enlace.png',
            'apab_volver' : 'info/volver.html',
            'apab_icono_borrar' : 'info/trash-bin.png',
            'apab_icono_mas' : 'info/ojo.png',
            'apab_icono_reservar' : 'info/reserva.png',
            'apab_icono_instalar' : 'info/conectar.png',
            'apab_paginaInicial':'info/imagen2.png',
            'apab_PAWSture_logo':'info/Imagen1.png'
            }
