

def contextoSensores(request):
    return {'tabla_sensor': 'sensores/tablaSensor.html'
            }
