from django.db import models
from granjas.models import Granja

class Sensor( models.Model ):
    idSensor = models.CharField( max_length=20, primary_key=True)   # Clave primaria. Es el identificador único del sensor.
    mote = models.CharField( max_length=50, null=True, unique=True)            # Nombre del sensor.                                                                    # en la granja.
    humedad = models.FloatField( max_length=10, null=True)     
    fechaUltMedida = models.DateTimeField(auto_now=False, null=True)
    GranjaidGranja = models.ForeignKey(Granja, on_delete=models.SET_NULL, null=True)