from django import forms

class RegSensor( forms.Form ):
    mote = forms.CharField( label='Nombre del sensor', max_length=50)
    pass

