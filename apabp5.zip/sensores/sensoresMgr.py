from django.db import IntegrityError
from django.core.exceptions import ObjectDoesNotExist

from django.db.models import Max, Min

from .models import Sensor

import random
import string

from typing import Union

LONG_ID = 12

class GestorSensores:
    def registrarSensor(mote : str ) -> dict:
        try:
            idSensor = ''.join(  random.choice( string.ascii_letters) for i in range(LONG_ID))
            Sensor.objects.get(idSensor=idSensor)
            res = {'code': 2}
        except ObjectDoesNotExist:
            sensor = Sensor(idSensor=idSensor, mote=mote)
            try:                
                sensor.save()
                res = {'code': 0}
            except IntegrityError:
                res = {'code': 1}
        return res
    

    def buscarSensor( idSensor : str = None ) -> Union[list, Sensor, None]:
        sensores = list( Sensor.objects.all().order_by('-mote').values())
        return sensores


    def borrarSensor( idSensor : str ) -> Union[ Sensor, None]:
        if ( idSensor is None ):
            return None
        
        try:
            sensor = Sensor.objects.get( idSensor = idSensor)
            sensor.delete()
            return sensor
            pass
        except ObjectDoesNotExist:
            return None
            pass
        pass
    pass