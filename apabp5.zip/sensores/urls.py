from django.urls import path
from sensores import views
# Ver https://www.bookaapi.com/book-blogging/url-structure/

urlpatterns = [
    path('', views.mostrarSensores, name='ver-sensores'),
    path('borrar/<str:idSensor>/', views.borrarSensor, name='borrar-sensor'),
    path('formularios/registrar-sensor/', views.formRegSensor, name='registrar-sensor')
]