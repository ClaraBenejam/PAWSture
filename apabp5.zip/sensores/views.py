from django.views.decorators.csrf import csrf_exempt
from django.http import HttpResponseNotAllowed, HttpResponseBadRequest, HttpResponseServerError
import json
from django.contrib.auth.decorators import permission_required
from django.http import HttpResponse, HttpRequest
from datetime import *
from django.shortcuts import render
from django.urls import reverse
from sensores.forms import RegSensor
from sensores.sensoresMgr import GestorSensores


REG_SENSOR = 'sensores/regSensor.html'
LISTA_SENSORES = 'sensores/listaSensores.html'
RESULTADO = 'info/res.html'


@permission_required(['sensores.add_sensor'], raise_exception=True)
def formRegSensor( request : HttpRequest ) -> HttpResponse:

    if ((request.method != 'GET') and (request.method != 'POST')):
        error = "Operación de protocolo empleada incorrecta. Fallo en el navegador"
        op = "Registro de una nuevo sensor"
        return render(request, RESULTADO, {'errorMsg': error, "texto_op" : op }, status=405)
        pass

    if (request.method == 'GET'):
        form = RegSensor()
        return render(request, REG_SENSOR, {'formulario': form})
        pass

    if (request.method == 'POST'):
        form = RegSensor(request.POST)
        if (form.is_valid()):
            mote = form.cleaned_data['mote']
            res = GestorSensores.registrarSensor(mote)
            if (res['code'] == 0):
                texto = "El sensor \'"+mote+"\' añadido correctamente"
                op = "Registro de un nuevo sensor"
                return render(request, RESULTADO, {'texto': texto, "texto_op" : op, 'url_volver': reverse('registrar-sensor') })
                pass
            else:
                error = "Error"
                if (res['code'] == 1):
                    error = 'Ya hay un sensor con mote \''+mote+'\''
                    pass
                if (res['code'] == 2):
                    error = 'Ya existe el sensor con mote: '+mote
                    pass
                return render(request, REG_SENSOR, {'formulario': form, 'errorMsg': error})
                pass
            pass
        else:
            error="Error en el formulario"
            return render(request, REG_SENSOR, {'formulario': form, 'errorMsg': error})
            pass
    pass

@permission_required(['sensores.view_sensor'], raise_exception=True)
def  mostrarSensores( request : HttpRequest ) -> HttpResponse:
    if (request.method == 'GET'):
        lista = GestorSensores.buscarSensor()
        return render(request, LISTA_SENSORES, {'lista': lista})
        pass

    error = "Operación de protocolo empleada incorrecta. Fallo en el navegador"
    op = "Búsqueda de sensores"
    return render(request, RESULTADO, {'errorMsg': error, "texto_op" : op }, status=405)
    pass

@permission_required(['sensores.delete_sensor'], raise_exception=True)
def borrarSensor(request : HttpRequest, idSensor: str ) -> HttpResponse:
    if ( request.method == 'DELETE'):
        res = GestorSensores.borrarSensor(idSensor)
        if ( res is None):
            error = "No existe el sensor con identificador " + idSensor
            op = "Eliminar sensor"
            return render(request, RESULTADO, {'errorMsg': error, "texto_op" : op, "url_volver" : reverse('ver-sensores') })
            pass
        else:
            texto = "El sensor \'" + idSensor + "\' ha sido borrado."
            op = "Eliminar sensor"
            return render(request, RESULTADO, {'texto': texto, "texto_op" : op, "url_volver" : reverse('ver-sensores') })
            pass
        pass
    error = "Operación de protocolo empleada incorrecta. Fallo en el navegador"
    op = "Eliminar sensor"
    return render(request, RESULTADO, {'errorMsg': error, "texto_op" : op, "url_volver" : reverse('ver-sensores') }, status=405)
    pass

