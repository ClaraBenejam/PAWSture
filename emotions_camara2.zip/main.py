import cv2
from datetime import datetime

from emotion_detector import analyze_frame, stress_from_emotion
from cloud_db import insert_emotion

NEGATIVE_EMOTIONS = {"angry", "fear", "disgust", "sad", "neutral"}
STRESS_TIME_THRESHOLD = 5  # seconds
import random  

current_emotion = None
emotion_start_time = None

# ================================
# SIMPLE RECOMMENDATION SYSTEM (ADD THIS)
# ================================

last_recommendation_time = None

# Simple exercises
BREATHING_EXERCISES = [
    "🌬️ 4-7-8 Breathing: Inhale 4s, hold 7s, exhale 8s. Repeat 4 times",
    "🌬️ Diaphragmatic breathing: Breathe deeply from the abdomen for 2 minutes"
]

ACTIVE_BREAKS = [
    "🏃 Active break: Stretch neck, shoulders and back - 3 minutes",
    "🏃 Spinal decompression: Gentle torso and hip rotations - 4 minutes"
]

def check_recommendation(emotion, stress_level):
    """Checks whether a recommendation should be given based on the current emotion"""
    global last_recommendation_time
    
    current_time = datetime.now()
    
    # Prevent spam - only 1 recommendation every 10 minutes
    if last_recommendation_time:
        time_diff = (current_time - last_recommendation_time).total_seconds()
        if time_diff < 600:  # 10 minutes
            return None
    
    emotion_lower = emotion.lower()
    
    # RECOMMENDATION LOGIC
    if stress_level == "alto" and emotion_lower in NEGATIVE_EMOTIONS:
        # Case 1: High stress + negative emotions → Active break
        last_recommendation_time = current_time
        recommendation = random.choice(ACTIVE_BREAKS)
        print(f"\n🎯 RECOMMENDATION: {recommendation}")
        print(f"📊 Reason: High stress and {emotion} detected")
        return recommendation
        
    elif emotion_lower in NEGATIVE_EMOTIONS:
        # Case 2: Only negative emotions → Breathing exercise
        last_recommendation_time = current_time
        recommendation = random.choice(BREATHING_EXERCISES)
        print(f"\n🎯 RECOMMENDATION: {recommendation}")
        print(f"📊 Reason: Emotion {emotion} detected")
        return recommendation
    return None

def main():
    cap = cv2.VideoCapture(0, cv2.CAP_DSHOW)
    if not cap.isOpened():
        print("Camera could not be opened")
        return

    currently_negative = False
    negative_start_time = None

    while True:
        ret, frame = cap.read()
        if not ret:
            print("Could not read a frame from the camera")
            break

        frame = cv2.flip(frame, 1)

        now = datetime.now()
        results = analyze_frame(frame)

        for r in results:
            x, y, w, h = r["box"]
            emotion = r["emotion"]
            gender = r["gender"]

            base_score, base_level = stress_from_emotion(emotion)
            em_lower = emotion.lower()

            if em_lower in NEGATIVE_EMOTIONS:
                if not currently_negative:
                    currently_negative = True
                    negative_start_time = now

                elapsed = 0
                if negative_start_time is not None:
                    elapsed = (now - negative_start_time).total_seconds()

                if elapsed < STRESS_TIME_THRESHOLD:
                    stress_score = 0.0
                    stress_level = "low"
                elif elapsed < STRESS_TIME_THRESHOLD * 2:
                    stress_score = base_score / 2
                    stress_level = "medium"
                else:
                    stress_score = base_score
                    stress_level = base_level
            else:
                currently_negative = False
                negative_start_time = None
                stress_score = 0.0
                stress_level = "low"

            cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 255, 0), 2)

            text1 = f"{emotion} - {gender}"
            cv2.putText(frame, text1, (x, y - 25),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 0, 255), 2)

            text2 = f"stress: {stress_level} ({stress_score:.1f})"
            cv2.putText(frame, text2, (x, y - 5),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 0), 2)

            # NOW: save to Supabase
            insert_emotion(emotion, gender, stress_score, stress_level)

            check_recommendation(emotion, stress_level)

        cv2.imshow("Emotions - press q to quit", frame)

        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    cap.release()
    cv2.destroyAllWindows()


if __name__ == "__main__":
    main()
