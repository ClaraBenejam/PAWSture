from pathlib import Path
from recommendation_system import RecommendationSystem
import json


def run_case(name, data):
    rs = RecommendationSystem(Path('.'))
    rs.min_interval_minutes = 0  # allow back-to-back calls for testing
    rs.get_recent_emotions_supabase = lambda minutes=5: data
    rec = rs.generate_recommendation()
    print(f"--- {name} ---")
    print(json.dumps(rec, ensure_ascii=False, indent=2))
    print()


if __name__ == '__main__':
    cases = [
        ("High stress + negative emotion", [
            {"emotion": "sad", "stress_level": "high", "created_at": "2025-11-21 12:00:00"}
        ]),
        ("High stress only", [
            {"emotion": "happy", "stress_level": "high", "created_at": "2025-11-21 12:01:00"}
        ]),
        ("Negative emotion only", [
            {"emotion": "angry", "stress_level": "low", "created_at": "2025-11-21 12:02:00"}
        ]),
        ("No signs of issues", [
            {"emotion": "happy", "stress_level": "low", "created_at": "2025-11-21 12:03:00"}
        ]),
    ]

    for name, data in cases:
        run_case(name, data)
