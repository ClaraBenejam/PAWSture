# cloud_db.py
from datetime import datetime

from supabase import create_client, Client
from datetime import datetime, timedelta  # Añade timedelta

SUPABASE_URL = "https://sunsfqthmwotlbfcgmay.supabase.co"
SUPABASE_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InN1bnNmcXRobXdvdGxiZmNnbWF5Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjM0MDQwNjcsImV4cCI6MjA3ODk4MDA2N30.dLSgRjiiK4dDrYcwenp2RHBkMdQxYglficyyRripRN8"

if not SUPABASE_URL or not SUPABASE_KEY:
    raise RuntimeError("SUPABASE_URL or SUPABASE_KEY are missing from environment variables")

supabase: Client = create_client(SUPABASE_URL, SUPABASE_KEY)


def insert_emotion(emotion: str, gender: str, stress_score: float, stress_level: str, created_at: str | None = None):
    """
    Inserts a record into the emotions table in Supabase.
    """
    if created_at is None:
        created_at = datetime.now().isoformat(sep=" ", timespec="seconds")

    data = {
        "emotion": emotion,
        "gender": gender,
        "stress_score": stress_score,
        "stress_level": stress_level,
        "created_at": created_at,
    }

    # Supabase API call
    supabase.table("emotions").insert(data).execute()

# Añade estas funciones al final de tu cloud_db.py actual

def insert_recommendation(recommendation_data: dict):
    """
    Inserts a recommendation record into the recommendations table.
    """
    data = {
        "id": recommendation_data["id"],
        "recommendation_type": recommendation_data["recommendation_type"],
        "name": recommendation_data["name"],
        "description": recommendation_data["description"],
        "duration": recommendation_data["duration"],
        "reason": recommendation_data["reason"],
        "urgency": recommendation_data["urgency"],
        "steps": recommendation_data.get("steps", []),
        "emoji": recommendation_data.get("emoji", ""),
        "created_at": datetime.now().isoformat(sep=" ", timespec="seconds")
    }

    try:
        result = supabase.table("recommendations").insert(data).execute()
        print(f"✅ Recommendation saved to database: {recommendation_data['id']}")
        return result
    except Exception as e:
        print(f"❌ Error saving recommendation to database: {e}")
        return None

def insert_recommendation_response(recommendation_id: str, user_id: int, username: str, response: str, response_reason: str = None):
    """
    Inserts a user response to a recommendation.
    """
    data = {
        "recommendation_id": recommendation_id,
        "user_id": user_id,
        "username": username,
        "response": response,  # 'accept', 'postpone', 'reject'
        "response_reason": response_reason,
        "created_at": datetime.now().isoformat(sep=" ", timespec="seconds")
    }

    try:
        result = supabase.table("recommendation_responses").insert(data).execute()
        print(f"✅ Response saved to database: {user_id} -> {response} for {recommendation_id}")
        return result
    except Exception as e:
        print(f"❌ Error saving response to database: {e}")
        return None

def get_recommendation_responses(recommendation_id: str):
    """
    Gets all responses for a specific recommendation.
    """
    try:
        result = supabase.table("recommendation_responses")\
            .select("*")\
            .eq("recommendation_id", recommendation_id)\
            .execute()
        return result.data
    except Exception as e:
        print(f"❌ Error fetching responses: {e}")
        return []

def get_user_response_stats(user_id: int, days: int = 30):
    """
    Gets response statistics for a specific user.
    """
    try:
        since_date = (datetime.now() - timedelta(days=days)).isoformat(sep=" ", timespec="seconds")
        
        # Get all responses for the user
        result = supabase.table("recommendation_responses")\
            .select("response")\
            .eq("user_id", user_id)\
            .gte("created_at", since_date)\
            .execute()
        
        # Count responses manually
        stats = {'accept': 0, 'postpone': 0, 'reject': 0}
        for item in result.data:
            response_type = item.get('response')
            if response_type in stats:
                stats[response_type] += 1
        
        return stats
    except Exception as e:
        print(f"❌ Error fetching user stats: {e}")
        return {}

def get_recommendation_analytics(days: int = 7):
    """
    Gets analytics for recommendations in the specified period.
    """
    try:
        since_date = (datetime.now() - timedelta(days=days)).isoformat(sep=" ", timespec="seconds")
        
        # Get all responses in the period
        responses_result = supabase.table("recommendation_responses")\
            .select("response")\
            .gte("created_at", since_date)\
            .execute()
        
        # Count responses manually
        response_counts = {'accept': 0, 'postpone': 0, 'reject': 0}
        for item in responses_result.data:
            response_type = item.get('response')
            if response_type in response_counts:
                response_counts[response_type] += 1
        
        # Get all recommendations in the period
        recommendations_result = supabase.table("recommendations")\
            .select("recommendation_type")\
            .gte("created_at", since_date)\
            .execute()
        
        # Count recommendations by type manually
        recommendation_types = {}
        for item in recommendations_result.data:
            rec_type = item.get('recommendation_type')
            recommendation_types[rec_type] = recommendation_types.get(rec_type, 0) + 1
        
        analytics = {
            "response_counts": response_counts,
            "recommendation_types": recommendation_types,
            "total_recommendations": len(recommendations_result.data),
            "period_days": days
        }
        
        return analytics
    except Exception as e:
        print(f"❌ Error fetching analytics: {e}")
        return {}