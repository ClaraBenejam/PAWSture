import sqlite3
from datetime import datetime, timedelta
from pathlib import Path
import random
import requests
import re

class RecommendationSystem:
    def __init__(self, db_path: Path):
        self.db_path = db_path
        self.last_recommendation_time = None
        self.min_interval_minutes = 1  # Evitar spam de recomendaciones
        
        # Cargar credenciales de Supabase para acceder a los datos
        self.supabase_url, self.supabase_key = self._load_supabase_credentials()
        
        self.breathing_exercises = [
            {
                "name": "Respiración 4-7-8",
                "description": "Inhala 4 segundos, mantén 7 segundos, exhala 8 segundos. Repite 4 veces.",
                "duration": "2 minutos",
                "type": "breathing",
                "steps": [
                    "Siéntate cómodamente con la espalda recta",
                    "Inhala por la nariz contando hasta 4",
                    "Mantén la respiración contando hasta 7", 
                    "Exhala por la boca contando hasta 8",
                    "Repite este ciclo 4 veces"
                ]
            },
            {
                "name": "Respiración Diafragmática",
                "description": "Respiración profunda desde el diafragma para reducir el estrés",
                "duration": "3 minutos",
                "type": "breathing",
                "steps": [
                    "Coloca una mano en tu pecho y otra en el abdomen",
                    "Inhala profundamente por la nariz, sintiendo cómo se expande el abdomen",
                    "Exhala lentamente por la boca",
                    "Repite durante 3 minutos concentrándote en la respiración"
                ]
            }
        ]
        
        self.active_breaks = [
            {
                "name": "Pausa Activa Completa",
                "description": "Estiramientos para liberar tensión muscular acumulada",
                "duration": "5 minutos", 
                "type": "active_break",
                "steps": [
                    "Gira suavemente el cuello hacia ambos lados (10 repeticiones)",
                    "Eleva y baja los hombros (8 repeticiones)",
                    "Estira los brazos hacia arriba y mantén 15 segundos",
                    "Inclínate suavemente hacia los lados (5 repeticiones por lado)",
                    "Camina por la habitación durante 1 minuto"
                ]
            },
            {
                "name": "Descompresión Vertebral",
                "description": "Ejercicios para aliviar la tensión lumbar y mejorar la postura",
                "duration": "4 minutos",
                "type": "active_break", 
                "steps": [
                    "De pie, inclínate hacia adelante dejando colgar los brazos (20 segundos)",
                    "Realiza rotaciones suaves de cadera (10 repeticiones por lado)",
                    "Estira la espalda en posición de gato (15 repeticiones)",
                    "Haz giros suaves de torso sentado (8 repeticiones por lado)"
                ]
            }
        ]

    def _load_supabase_credentials(self):
        """Carga las credenciales de Supabase desde cloud_db.py"""
        try:
            cloud_db_path = Path(__file__).parent / "cloud_db.py"
            txt = cloud_db_path.read_text(encoding="utf-8")
            m_url = re.search(r"SUPABASE_URL\s*=\s*[\"'](.+?)[\"']", txt)
            m_key = re.search(r"SUPABASE_KEY\s*=\s*[\"'](.+?)[\"']", txt)
            if m_url and m_key:
                return m_url.group(1).strip(), m_key.group(1).strip()
        except Exception as e:
            print(f"Error cargando credenciales Supabase: {e}")
        return None, None

    def get_recent_emotions_supabase(self, minutes=5):
        """Obtiene emociones recientes desde Supabase"""
        if not self.supabase_url or not self.supabase_key:
            print("No hay credenciales de Supabase disponibles")
            return []
            
        try:
            headers = {
                "apikey": self.supabase_key,
                "Authorization": f"Bearer {self.supabase_key}",
                "Accept": "application/json",
            }

            since_time = (datetime.now() - timedelta(minutes=minutes)).isoformat(sep=" ", timespec="seconds")
            url = f"{self.supabase_url}/rest/v1/emotions?select=emotion,stress_level,created_at&created_at=gte.{since_time}&order=created_at.desc"

            response = requests.get(url, headers=headers)
            response.raise_for_status()
            data = response.json()
            
            return data if isinstance(data, list) else []
            
        except Exception as e:
            print(f"Error obteniendo emociones de Supabase: {e}")
            return []

    def analyze_emotional_state(self):
        """Analiza el estado emocional para determinar recomendaciones"""
        recent_data = self.get_recent_emotions_supabase(5)  # Últimos 5 minutos
        
        if not recent_data:
            return None

        # Verificar intervalo mínimo entre recomendaciones
        if self.last_recommendation_time:
            time_since_last = (datetime.now() - self.last_recommendation_time).total_seconds() / 60
            if time_since_last < self.min_interval_minutes:
                return None

        # Simplificar la lógica: usar condiciones booleanas directas
        negative_emotions = {"angry", "fear", "disgust", "sad"}

        has_high_stress = False
        has_negative_emotion = False
        total_records = len(recent_data)

        for record in recent_data:
            emotion = str(record.get('emotion', '')).lower()
            stress_level = str(record.get('stress_level', '')).lower()

            if stress_level == "alto":
                has_high_stress = True
            if emotion in negative_emotions:
                has_negative_emotion = True

        print(f"🔍 Análisis emocional: registros={total_records}, estrés_alto={has_high_stress}, emociones_negativas={has_negative_emotion}")

        # Regla solicitada por el usuario:
        # - Si el estrés es alto AND hay emociones malas -> recomendar pausa activa
        # - Si el estrés es alto OR hay emociones malas -> recomendar respiración
        if has_high_stress and has_negative_emotion:
            self.last_recommendation_time = datetime.now()
            return {
                "recommendation_type": "active_break",
                "reason": f"Detectado estrés alto y emociones negativas en los últimos {total_records} registros.",
                "urgency": "high"
            }
        elif has_high_stress or has_negative_emotion:
            self.last_recommendation_time = datetime.now()
            return {
                "recommendation_type": "breathing",
                "reason": f"Detectado estrés alto o emociones negativas en los últimos {total_records} registros.",
                "urgency": "medium"
            }
        
        return None

    def generate_recommendation(self):
        """Generates a personalized recommendation and saves to database"""
        analysis = self.analyze_emotional_state()
        
        if not analysis:
            return None
        
        if analysis["recommendation_type"] == "active_break":
            activity = random.choice(self.active_breaks)
            emoji = "🏃"
        else:
            activity = random.choice(self.breathing_exercises)
            emoji = "🌬️"
        
        # Create unique ID
        recommendation_id = f"rec_{datetime.now().strftime('%Y%m%d%H%M%S')}_{random.randint(1000,9999)}"
        
        recommendation = {
            **analysis,
            **activity,
            "emoji": emoji,
            "timestamp": datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            "id": recommendation_id
        }
        
        # Save recommendation to database
        from cloud_db import insert_recommendation
        insert_recommendation(recommendation)
        
        return recommendation

    def format_telegram_message(self, recommendation):
        """Formatea la recomendación para Telegram"""
        if recommendation["recommendation_type"] == "active_break":
            title = "🏃 PAUSA ACTIVA RECOMENDADA"
        else:
            title = "🌬️ EJERCICIO DE RESPIRACIÓN"
        
        message = f"""
{title}

*{recommendation['name']}*
_{recommendation['description']}_

⏱️ *Duración:* {recommendation['duration']}
📊 *Razón:* {recommendation['reason']}

*Pasos a seguir:*
"""
        
        # Agregar pasos
        for i, step in enumerate(recommendation.get('steps', []), 1):
            message += f"{i}. {step}\n"
        
        message += f"\n💡 _Recomendación generada: {datetime.now().strftime('%H:%M')}_"
        
        return message

    def send_recommendation_to_telegram(self, recommendation, bot_token: str, chat_ids):
        """Envía la recomendación a una lista de `chat_ids` usando la Bot API de Telegram.

        - `bot_token`: token del bot (string)
        - `chat_ids`: iterable de chat_id (int/str)

        Devuelve un dict con los resultados por chat_id.
        """
        if not bot_token:
            raise ValueError("Se requiere 'bot_token' para enviar mensajes a Telegram")

        message = self.format_telegram_message(recommendation)
        url = f"https://api.telegram.org/bot{bot_token}/sendMessage"
        results = {}

        for chat_id in chat_ids:
            payload = {
                "chat_id": chat_id,
                "text": message,
                "parse_mode": "Markdown"
            }

            try:
                r = requests.post(url, data=payload, timeout=10)
                r.raise_for_status()
                results[chat_id] = {"ok": True, "response": r.json()}
            except Exception as e:
                results[chat_id] = {"ok": False, "error": str(e)}

        return results
    
    def create_recommendation_keyboard(self, recommendation_id):
        """Creates inline keyboard with options for the recommendation"""
        from telegram import InlineKeyboardButton, InlineKeyboardMarkup
        
        keyboard = [
            [
                InlineKeyboardButton("✅ Accept", callback_data=f"accept_{recommendation_id}"),
                InlineKeyboardButton("⏸️ Postpone", callback_data=f"postpone_{recommendation_id}"),
            ],
            [
                InlineKeyboardButton("❌ Reject", callback_data=f"reject_{recommendation_id}"),
                InlineKeyboardButton("📊 More info", callback_data=f"info_{recommendation_id}"),
            ]
        ]
        return InlineKeyboardMarkup(keyboard)

async def send_recommendation_to_telegram(self, recommendation, bot, chat_ids):
    """Sends recommendation with interactive buttons"""
    message = self.format_telegram_message(recommendation)
    keyboard = self.create_recommendation_keyboard(recommendation['id'])
    
    results = {}
    
    for chat_id in chat_ids:
        try:
            sent_message = await bot.send_message(
                chat_id=chat_id,
                text=message,
                parse_mode="Markdown",
                reply_markup=keyboard
            )
            results[chat_id] = {"ok": True, "message_id": sent_message.message_id}
        except Exception as e:
            results[chat_id] = {"ok": False, "error": str(e)}
    
    return results