import sqlite3
from datetime import datetime, timedelta
from pathlib import Path
import random
import requests
import re

class RecommendationSystem:
    def __init__(self, db_path: Path):
        self.db_path = db_path
        self.last_recommendation_time = None
        self.min_interval_minutes = 1  # Evitar spam de recomendaciones
        
        # Cargar credenciales de Supabase para acceder a los datos
        self.supabase_url, self.supabase_key = self._load_supabase_credentials()
        
        self.breathing_exercises = [
            {
            "name": "4-7-8 Breathing",
            "description": "Inhale for 4 seconds, hold for 7 seconds, exhale for 8 seconds. Repeat 4 times.",
            "duration": "2 minutes",
            "type": "breathing",
            "steps": [
                "Sit comfortably with your back straight",
                "Inhale through your nose counting to 4",
                "Hold your breath counting to 7",
                "Exhale through your mouth counting to 8",
                "Repeat this cycle 4 times"
            ]
            },
            {
            "name": "Diaphragmatic Breathing",
            "description": "Deep breathing from the diaphragm to reduce stress",
            "duration": "3 minutes",
            "type": "breathing",
            "steps": [
                "Place one hand on your chest and the other on your abdomen",
                "Breathe in deeply through your nose, feeling your abdomen expand",
                "Exhale slowly through your mouth",
                "Repeat for 3 minutes while focusing on your breathing"
            ]
        }
        ]
        
        self.active_breaks = [
            {
            "name": "Full Active Break",
            "description": "Active rest break",
            "duration": "5 minutes",
            "type": "active_break",
            "steps": [
                "Stand up from your seat",
                "Move around: walk, stretch your arms and legs",
                "If possible, go outside to breathe some fresh air and socialize"
            ]
        }, 
        {
            "name": "Mindful Coffee Break",
            "description": "A short break to clear your mind and recharge your energy",
            "duration": "5 minutes",
            "type": "active_break",
            "steps": [
                "Stand up from your workspace",
                "Walk calmly to the kitchen or coffee machine",
                "Prepare a coffee or warm drink of your choice",
                "While waiting, inhale deeply and exhale slowly",
                "Take a moment to enjoy the aroma and the first sip without distractions",
                "Return to your workspace feeling refreshed"
            ]
        }
        ]

    def _load_supabase_credentials(self):
        """Load Supabase credentials from cloud_db.py"""
        try:
            cloud_db_path = Path(__file__).parent / "cloud_db.py"
            txt = cloud_db_path.read_text(encoding="utf-8")
            m_url = re.search(r"SUPABASE_URL\s*=\s*[\"'](.+?)[\"']", txt)
            m_key = re.search(r"SUPABASE_KEY\s*=\s*[\"'](.+?)[\"']", txt)
            if m_url and m_key:
                return m_url.group(1).strip(), m_key.group(1).strip()
        except Exception as e:
            print(f"Error loading Supabase credentials: {e}")
        return None, None

    def get_recent_emotions_supabase(self, minutes=5):
        """Fetches recent emotions from Supabase"""
        if not self.supabase_url or not self.supabase_key:
            print("No Supabase credentials available")
            return []
            
        try:
            headers = {
                "apikey": self.supabase_key,
                "Authorization": f"Bearer {self.supabase_key}",
                "Accept": "application/json",
            }

            since_time = (datetime.now() - timedelta(minutes=minutes)).isoformat(sep=" ", timespec="seconds")
            url = f"{self.supabase_url}/rest/v1/emotions?select=emotion,stress_level,created_at&created_at=gte.{since_time}&order=created_at.desc"

            response = requests.get(url, headers=headers)
            response.raise_for_status()
            data = response.json()
            
            return data if isinstance(data, list) else []
            
        except Exception as e:
            print(f"Error loading Supabase credentials: {e}")
            return []

    def analyze_emotional_state(self):
        """Analyzes emotional state to determine recommendations"""
        recent_data = self.get_recent_emotions_supabase(5)  # Últimos 5 minutos
        
        if not recent_data:
            return None

        # Verificar intervalo mínimo entre recomendaciones
        if self.last_recommendation_time:
            time_since_last = (datetime.now() - self.last_recommendation_time).total_seconds() / 60
            if time_since_last < self.min_interval_minutes:
                return None

        # Simplificar la lógica: usar condiciones booleanas directas
        negative_emotions = {"angry", "fear", "disgust", "sad"}

        has_high_stress = False
        has_negative_emotion = False
        total_records = len(recent_data)

        for record in recent_data:
            emotion = str(record.get('emotion', '')).lower()
            stress_level = str(record.get('stress_level', '')).lower()

            if stress_level == "alto":
                has_high_stress = True
            if emotion in negative_emotions:
                has_negative_emotion = True

        print(f"🔍 Emotional analysis: records={total_records}, high_stress={has_high_stress}, negative_emotions={has_negative_emotion}")

        # Regla solicitada por el usuario:
        # - Si el estrés es alto AND hay emociones malas -> recomendar pausa activa
        # - Si el estrés es alto OR hay emociones malas -> recomendar respiración
        if has_high_stress and has_negative_emotion:
            self.last_recommendation_time = datetime.now()
            return {
                "recommendation_type": "active_break",
                "reason": f"High stress and negative emotions detected in the last {total_records} records.",
                "urgency": "high"
            }
        elif has_high_stress or has_negative_emotion:
            self.last_recommendation_time = datetime.now()
            return {
                "recommendation_type": "breathing",
                "reason": f"High stress or negative emotions detected in the last {total_records} records.",
                "urgency": "medium"
            }
        
        return None

    def generate_recommendation(self):
        """Generates a personalized recommendation and saves to database"""
        analysis = self.analyze_emotional_state()
        
        if not analysis:
            return None
        
        if analysis["recommendation_type"] == "active_break":
            activity = random.choice(self.active_breaks)
            emoji = "🏃"
        else:
            activity = random.choice(self.breathing_exercises)
            emoji = "🌬️"
        
        # Create unique ID
        recommendation_id = f"rec_{datetime.now().strftime('%Y%m%d%H%M%S')}_{random.randint(1000,9999)}"
        
        recommendation = {
            **analysis,
            **activity,
            "emoji": emoji,
            "timestamp": datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            "id": recommendation_id
        }
        
        # Save recommendation to database
        from cloud_db import insert_recommendation
        insert_recommendation(recommendation)
        
        return recommendation

    def format_telegram_message(self, recommendation):
        """Formats the recommendation for Telegram"""
        if recommendation["recommendation_type"] == "active_break":
            title = "🏃 RECOMMENDED ACTIVE BREAK"
        else:
            title = "🌬️ BREATHING EXERCISE"
        
        message = f"""
{title}

*{recommendation['name']}*
_{recommendation['description']}_

⏱️ *Duración:* {recommendation['duration']}
📊 *Razón:* {recommendation['reason']}

*Pasos a seguir:*
"""
        
        # Agregar pasos
        for i, step in enumerate(recommendation.get('steps', []), 1):
            message += f"{i}. {step}\n"
        
        message += f"\n💡 _Recomendation generated: {datetime.now().strftime('%H:%M')}_"
        
        return message

    def send_recommendation_to_telegram(self, recommendation, bot_token: str, chat_ids):
        """Sends the recommendation to a list of `chat_ids` using the Telegram Bot API.
            - `bot_token`: bot token (string)
            - `chat_ids`: iterable of chat_id (int/str)
        Returns a dict with the results per chat_id.
        """

        if not bot_token:
            raise ValueError("bot_token' is required to send messages to Telegram")

        message = self.format_telegram_message(recommendation)
        url = f"https://api.telegram.org/bot{bot_token}/sendMessage"
        results = {}

        for chat_id in chat_ids:
            payload = {
                "chat_id": chat_id,
                "text": message,
                "parse_mode": "Markdown"
            }

            try:
                r = requests.post(url, data=payload, timeout=10)
                r.raise_for_status()
                results[chat_id] = {"ok": True, "response": r.json()}
            except Exception as e:
                results[chat_id] = {"ok": False, "error": str(e)}

        return results
    
    def create_recommendation_keyboard(self, recommendation_id):
        """Creates inline keyboard with options for the recommendation"""
        from telegram import InlineKeyboardButton, InlineKeyboardMarkup
        
        keyboard = [
            [
                InlineKeyboardButton("✅ Accept", callback_data=f"accept_{recommendation_id}"),
                InlineKeyboardButton("⏸️ Postpone", callback_data=f"postpone_{recommendation_id}"),
            ],
            [
                InlineKeyboardButton("❌ Reject", callback_data=f"reject_{recommendation_id}"),
                InlineKeyboardButton("📊 More info", callback_data=f"info_{recommendation_id}"),
            ]
        ]
        return InlineKeyboardMarkup(keyboard)

async def send_recommendation_to_telegram(self, recommendation, bot, chat_ids):
    """Sends recommendation with interactive buttons"""
    message = self.format_telegram_message(recommendation)
    keyboard = self.create_recommendation_keyboard(recommendation['id'])
    
    results = {}
    
    for chat_id in chat_ids:
        try:
            sent_message = await bot.send_message(
                chat_id=chat_id,
                text=message,
                parse_mode="Markdown",
                reply_markup=keyboard
            )
            results[chat_id] = {"ok": True, "message_id": sent_message.message_id}
        except Exception as e:
            results[chat_id] = {"ok": False, "error": str(e)}
    
    return results