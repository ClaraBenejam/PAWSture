from pathlib import Path
import re
from datetime import datetime, timedelta
import requests
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ApplicationBuilder, CommandHandler, ContextTypes, CallbackQueryHandler
import asyncio
import os
import json
import sys

# Add the project root to Python path
REPO_ROOT = Path(__file__).resolve().parent
sys.path.append(str(REPO_ROOT))

# Import recommendation system and database functions
from recommendation_system import RecommendationSystem
from cloud_db import insert_recommendation_response, get_recommendation_responses, get_user_response_stats, get_recommendation_analytics

# ================================
# CONFIGURATION
# ================================

# Set with chat_ids stored in memory
CHAT_IDS = set()

# BOT_TOKEN: prefer environment variable for security
BOT_TOKEN = os.environ.get("BOT_TOKEN", "8151081242:AAGZCZucopD3f5FrQTrtw-JW6mAf5aUruCM")

# File to persist subscriber chat_ids
CHAT_STORE = REPO_ROOT / "chat_ids.json"

# Default chat IDs (env): can be set as '12345,67890' for automatic messages
DEFAULT_CHAT_IDS = set()
env_default = os.environ.get("DEFAULT_CHAT_IDS")
if env_default:
    for part in env_default.split(","):
        part = part.strip()
        if part:
            try:
                DEFAULT_CHAT_IDS.add(int(part))
            except ValueError:
                DEFAULT_CHAT_IDS.add(part)

# Initialize recommendation system
recommendation_system = RecommendationSystem(REPO_ROOT)

# ================================
# CHAT ID MANAGEMENT
# ================================

def load_persisted_chat_ids():
    """Loads chat_ids from `chat_ids.json` (if it exists)"""
    try:
        if CHAT_STORE.exists():
            txt = CHAT_STORE.read_text(encoding="utf-8")
            arr = json.loads(txt)
            return set(arr)
    except Exception as e:
        print(f"Error loading persisted chat_ids: {e}")
    return set()

def save_persisted_chat_ids(chat_ids):
    """Saves chat_ids to `chat_ids.json`"""
    try:
        CHAT_STORE.write_text(json.dumps(list(chat_ids), ensure_ascii=False), encoding="utf-8")
    except Exception as e:
        print(f"Error saving persisted chat_ids: {e}")

# Load persisted chat ids at startup
CHAT_IDS.update(load_persisted_chat_ids())

# ================================
# ALERT SYSTEM
# ================================

NEGATIVE_EMOTIONS = ["sad", "fear", "angry", "disgust"]

def check_alerts():
    """Checks for various alert conditions from Supabase data"""
    alerts = []
    try:
        cloud_db_path = REPO_ROOT / "cloud_db.py"
        txt = cloud_db_path.read_text(encoding="utf-8")
        m_url = re.search(r"SUPABASE_URL\s*=\s*[\"'](.+?)[\"']", txt)
        m_key = re.search(r"SUPABASE_KEY\s*=\s*[\"'](.+?)[\"']", txt)
        if not m_url or not m_key:
            print("SUPABASE_URL/SUPABASE_KEY not found in cloud_db.py")
            return alerts
        SUPABASE_URL = m_url.group(1).strip()
        SUPABASE_KEY = m_key.group(1).strip()
    except Exception as e:
        print(f"Error reading cloud_db.py: {e}")
        return alerts

    headers = {
        "apikey": SUPABASE_KEY,
        "Authorization": f"Bearer {SUPABASE_KEY}",
        "Accept": "application/json",
    }

    base = SUPABASE_URL.rstrip("/") + "/rest/v1/emotions"
    
    
    # 1) Increase in negative emotions in the last 2 minutes
    try:
        since = (datetime.now() - timedelta(minutes=2)).isoformat(sep=" ", timespec="seconds")
        in_list = ",".join([f'"{emotion}"' for emotion in NEGATIVE_EMOTIONS])
        url = f"{base}?select=id,emotion,created_at&emotion=in.({in_list})&created_at=gte.{since}"
        r = requests.get(url, headers=headers)
        r.raise_for_status()
        data = r.json()
        negatives = len(data) if isinstance(data, list) else 0
        if negatives >= 3:
            alerts.append("🔴 *Sudden increase in negative emotions* (≥3 in 2 minutes).")
    except Exception as e:
        print(f"Error querying negative emotions in Supabase (REST): {e}")

    # 2) High stress (latest entry)
    try:
        url = f"{base}?select=stress_level&order=created_at.desc&limit=1"
        r = requests.get(url, headers=headers)
        r.raise_for_status()
        data = r.json()
        if isinstance(data, list) and data:
            stress = data[0].get("stress_level")
            if stress == "high":
                alerts.append("🔴 *HIGH stress level detected*.")
    except Exception as e:
        print(f"Error querying stress in Supabase (REST): {e}")

    # 3) Fear loop (two fear entries within <60s)
    try:
        url = f"{base}?select=emotion,created_at&emotion=eq.fear&order=created_at.desc&limit=2"
        r = requests.get(url, headers=headers)
        r.raise_for_status()
        data = r.json()
        if isinstance(data, list) and len(data) == 2:
            t1 = datetime.fromisoformat(data[0]["created_at"].replace('Z', '+00:00'))
            t2 = datetime.fromisoformat(data[1]["created_at"].replace('Z', '+00:00'))
            if (t1 - t2).total_seconds() <= 60:
                alerts.append("🔴 *Repeated fear pattern (fear loop).*")
    except Exception as e:
        print(f"Error querying fear loop in Supabase (REST): {e}")

    # 4) Prolonged neutral (last 10 minutes)
    try:
        since = (datetime.now() - timedelta(minutes=10)).isoformat(sep=" ", timespec="seconds")
        url = f"{base}?select=id&emotion=eq.neutral&created_at=gte.{since}"
        r = requests.get(url, headers=headers)
        r.raise_for_status()
        data = r.json()
        neutral_count = len(data) if isinstance(data, list) else 0
        if neutral_count >= 20:
            alerts.append("🟠 *Too many 'neutral' detections (possible camera error).*")
    except Exception as e:
        print(f"Error querying neutrals in Supabase (REST): {e}")

    return alerts

def check_recommendations():
    """Checks and generates recommendations"""
    try:
        recommendation = recommendation_system.generate_recommendation()
        if recommendation:
            telegram_message = recommendation_system.format_telegram_message(recommendation)
            return recommendation, telegram_message
    except Exception as e:
        print(f"Error generating recommendation: {e}")
    
    return None, None

# ================================
# TELEGRAM BOT HANDLERS
# ================================

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Command /start - Subscribe user"""
    chat_id = update.message.chat_id
    CHAT_IDS.add(chat_id)
    save_persisted_chat_ids(CHAT_IDS)

    await update.message.reply_text(
        "🐾 *PAWSture Alert Bot - System Active*\n\n"
        "✅ *You have been successfully subscribed*\n"
        "📊 You will receive:\n"
        "   • Stress and negative emotion alerts\n"
        "   • Active break recommendations\n"
        "   • Personalized breathing exercises\n\n"
        "⏰ *Frequency:* Checks every 5 minutes\n"
        "🔧 Use /alerts to see current status\n"
        "💡 Use /recommendation for manual check\n"
        "📊 Use /stats for personal statistics\n\n"
        "*Interactive Features:*\n"
        "✅ Accept - Start the recommended activity\n"
        "⏸️ Postpone - Get reminded in 15 minutes\n"
        "❌ Reject - Decline this recommendation\n"
        "📊 More info - See response statistics",
        parse_mode="Markdown"
    )

async def alerts(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Command /alerts - Current status"""
    alerts_list = check_alerts()
    
    if not alerts_list:
        await update.message.reply_text(
            "🟢 *Current status:* No active alerts\n"
            "The system is monitoring your wellbeing...",
            parse_mode="Markdown"
        )
    else:
        msg = "📢 *Active alerts:*\n\n" + "\n".join(alerts_list)
        await update.message.reply_text(msg, parse_mode="Markdown")

async def recommendation(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Command /recommendation - Manual recommendation check"""
    recommendation, message = check_recommendations()
    
    if recommendation and message:
        # Send recommendation with interactive buttons
        keyboard = recommendation_system.create_recommendation_keyboard(recommendation['id'])
        await update.message.reply_text(
            message,
            parse_mode="Markdown",
            reply_markup=keyboard
        )
    else:
        await update.message.reply_text(
            "💚 *Optimal state:* No interventions needed at this moment.\n"
            "Your emotional state is within normal parameters.",
            parse_mode="Markdown"
        )

async def stats(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Command /stats - Personal response statistics"""
    user_id = update.message.from_user.id
    username = update.message.from_user.username or f"user_{user_id}"
    
    try:
        user_stats = get_user_response_stats(user_id, days=30)
        
        total_responses = sum(user_stats.values())
        
        if total_responses == 0:
            await update.message.reply_text(
                "📊 *Your Wellness Statistics*\n\n"
                "You haven't responded to any recommendations yet.\n\n"
                "When you receive recommendations, you can:\n"
                "✅ Accept - Start the activity\n"
                "⏸️ Postpone - Remind later\n"
                "❌ Reject - Decline for now",
                parse_mode="Markdown"
            )
            return
        
        acceptance_rate = (user_stats.get('accept', 0) / total_responses) * 100
        
        message = f"""
📊 *Your Wellness Statistics (30 days)*

*Response Summary:*
✅ Accepted: {user_stats.get('accept', 0)}
⏸️ Postponed: {user_stats.get('postpone', 0)}
❌ Rejected: {user_stats.get('reject', 0)}
📈 Acceptance Rate: {acceptance_rate:.1f}%

*Wellness Tips:*
- Aim for 70%+ acceptance rate
- Regular breaks improve productivity by 15%
- Small activities make a big difference in stress reduction
- Consistent breaks prevent burnout

Keep up the good work! 🎉
"""
        await update.message.reply_text(message, parse_mode="Markdown")
        
    except Exception as e:
        print(f"Error in stats command: {e}")
        await update.message.reply_text(
            "❌ Error fetching your statistics. Please try again later.",
            parse_mode="Markdown"
        )

# ================================
# RECOMMENDATION RESPONSE HANDLERS
# ================================

async def handle_recommendation_response(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handles responses to recommendations and saves to database"""
    query = update.callback_query
    await query.answer()
    
    user_id = query.from_user.id
    username = query.from_user.username or f"user_{user_id}"
    callback_data = query.data
    
    # Parse the callback data
    parts = callback_data.split('_')
    if len(parts) < 2:
        await query.edit_message_text("❌ Invalid response format.")
        return
        
    action = parts[0]
    recommendation_id = '_'.join(parts[1:])  # Handle IDs with underscores
    
    # Record the response in database
    if action in ['accept', 'postpone', 'reject']:
        # Save to database
        db_result = insert_recommendation_response(
            recommendation_id=recommendation_id,
            user_id=user_id,
            username=username,
            response=action
        )
        
        if db_result:
            # Update the message to show the response
            response_texts = {
                'accept': '✅ You ACCEPTED the recommendation',
                'postpone': '⏸️ You POSTPONED the recommendation', 
                'reject': '❌ You REJECTED the recommendation'
            }
            
            new_text = query.message.text + f"\n\n{response_texts[action]} by @{username}"
            
            # Remove buttons after response
            await query.edit_message_text(
                text=new_text,
                parse_mode="Markdown",
                reply_markup=None
            )
            
            print(f"User {user_id} ({username}) {action} recommendation {recommendation_id}")
            
            # Handle different response types
            if action == 'accept':
                await handle_accepted_recommendation(recommendation_id, user_id, username, context)
            elif action == 'postpone':
                await handle_postponed_recommendation(recommendation_id, user_id, username, context)
            elif action == 'reject':
                await handle_rejected_recommendation(recommendation_id, user_id, username, context)
                
        else:
            await query.edit_message_text(
                text="⚠️ Error saving your response. Please try again.",
                parse_mode="Markdown"
            )
    
    elif action == 'info':
        # Show additional information with response statistics
        await show_recommendation_info(recommendation_id, query)

async def handle_accepted_recommendation(recommendation_id, user_id, username, context):
    """Handles an accepted recommendation"""
    try:
        # Send confirmation
        await context.bot.send_message(
            chat_id=user_id,
            text="🎉 *Great decision!* Let's start with the recommended activity. ⏱️\n\n"
                 "We'll check in with you in 5 minutes to see how you're feeling.",
            parse_mode="Markdown"
        )
    except Exception as e:
        print(f"Error sending acceptance confirmation: {e}")

async def handle_postponed_recommendation(recommendation_id, user_id, username, context):
    """Handles a postponed recommendation"""
    try:
        await context.bot.send_message(
            chat_id=user_id,
            text="⏰ *Understood.* We'll remind you about this recommendation in 15 minutes.",
            parse_mode="Markdown"
        )
        
        # Schedule reminder
        context.job_queue.run_once(
            send_reminder, 
            15 * 60,  # 15 minutes
            data={'user_id': user_id, 'recommendation_id': recommendation_id}
        )
    except Exception as e:
        print(f"Error handling postponement: {e}")

async def handle_rejected_recommendation(recommendation_id, user_id, username, context):
    """Handles a rejected recommendation"""
    try:
        await context.bot.send_message(
            chat_id=user_id,
            text="❌ *Recommendation rejected.*\n\n"
                 "Remember that taking regular breaks is important for:\n"
                 "• Reducing stress and fatigue\n"
                 "• Improving focus and productivity\n"  
                 "• Preventing burnout\n"
                 "• Maintaining overall wellbeing",
            parse_mode="Markdown"
        )
    except Exception as e:
        print(f"Error handling rejection: {e}")

async def send_reminder(context):
    """Sends a reminder for postponed recommendations"""
    job_data = context.job.data
    user_id = job_data['user_id']
    recommendation_id = job_data['recommendation_id']
    
    try:
        keyboard = [
            [
                InlineKeyboardButton("✅ Start Now", callback_data=f"accept_{recommendation_id}"),
                InlineKeyboardButton("⏸️ Postpone Again", callback_data=f"postpone_{recommendation_id}"),
            ]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await context.bot.send_message(
            chat_id=user_id,
            text="🔔 *Reminder:* Ready to take that wellness break you postponed earlier?",
            parse_mode="Markdown",
            reply_markup=reply_markup
        )
    except Exception as e:
        print(f"Error sending reminder: {e}")

async def show_recommendation_info(recommendation_id, query):
    """Shows additional information about the recommendation with response stats"""
    # Get response statistics from database
    responses = get_recommendation_responses(recommendation_id)
    
    response_counts = {
        'accept': 0,
        'postpone': 0, 
        'reject': 0
    }
    
    for response in responses:
        response_type = response.get('response')
        if response_type in response_counts:
            response_counts[response_type] += 1
    
    total_responses = sum(response_counts.values())
    
    info_text = f"""
📊 *Recommendation Analytics*

*Community Response Statistics:*
✅ Accept: {response_counts['accept']}
⏸️ Postpone: {response_counts['postpone']}
❌ Reject: {response_counts['reject']}
👥 Total Responses: {total_responses}

*Benefits of this activity:*
• Reduces physical tension and stress
• Improves blood circulation  
• Enhances mental clarity and focus
• Prevents burnout and fatigue
• Boosts overall productivity

Your response helps us improve future recommendations for everyone! 💚
"""
    await query.edit_message_text(
        text=info_text,
        parse_mode="Markdown"
    )

# ================================
# PERIODIC TASKS
# ================================

async def send_alerts_periodically(context: ContextTypes.DEFAULT_TYPE):
    """Sends alerts and recommendations at each interval"""
    print(f"🔍 Checking alerts and recommendations at {datetime.now().strftime('%H:%M:%S')}")
    
    # Get alerts
    alerts_list = check_alerts()
    
    # Get recommendation
    recommendation, recommendation_message = check_recommendations()
    
    # Build recipients list
    recipients = set(CHAT_IDS) | set(DEFAULT_CHAT_IDS)
    
    if not recipients:
        print("No recipients available")
        return
    
    # Send alerts if any
    if alerts_list:
        alert_message = "📢 *Detected Alerts:*\n\n" + "\n".join(alerts_list)
        
        for chat_id in recipients:
            try:
                await context.bot.send_message(
                    chat_id=chat_id, 
                    text=alert_message, 
                    parse_mode="Markdown"
                )
                print(f"✅ Alert sent to {chat_id}")
            except Exception as e:
                print(f"Error sending alert to {chat_id}: {e}")
    
    # Send recommendation if available
    if recommendation and recommendation_message:
        try:
            # Send with interactive buttons
            keyboard = recommendation_system.create_recommendation_keyboard(recommendation['id'])
            
            for chat_id in recipients:
                try:
                    await context.bot.send_message(
                        chat_id=chat_id,
                        text=recommendation_message,
                        parse_mode="Markdown",
                        reply_markup=keyboard
                    )
                    print(f"✅ Recommendation sent to {chat_id}")
                except Exception as e:
                    print(f"Error sending recommendation to {chat_id}: {e}")
                    
        except Exception as e:
            print(f"Error processing recommendation: {e}")
    
    # Log status
    if not alerts_list and not recommendation:
        print("🟢 No alerts or recommendations to send")

# ================================
# MAIN FUNCTION
# ================================

def main():
    """Main function to start the bot"""
    if not BOT_TOKEN:
        print("❌ ERROR: BOT_TOKEN environment variable is required")
        return
    
    try:
        # Create application
        app = ApplicationBuilder().token(BOT_TOKEN).build()
        
        # Add command handlers
        app.add_handler(CommandHandler("start", start))
        app.add_handler(CommandHandler("alerts", alerts))
        app.add_handler(CommandHandler("recommendation", recommendation))
        app.add_handler(CommandHandler("stats", stats))
        
        # Add callback query handler for button responses
        app.add_handler(CallbackQueryHandler(handle_recommendation_response))
        
        # Schedule periodic tasks (every 5 minutes)
        app.job_queue.run_repeating(send_alerts_periodically, interval=60, first=10) # 300 es cada 5 mins
        
        # Startup message
        print("🤖 PAWSture Bot starting...")
        print("📊 Alert system: ACTIVE")
        print("💡 Recommendation system: ACTIVE")
        print("⏰ Checking every 5 minutes")
        print(f"👥 Subscribed users: {len(CHAT_IDS)}")
        print(f"📍 Default recipients: {len(DEFAULT_CHAT_IDS)}")
        print("🔧 Bot commands: /start, /alerts, /recommendation, /stats")
        print("🎯 Ready to receive messages...")
        
        # Start polling
        app.run_polling()
        
    except Exception as e:
        print(f"❌ Failed to start bot: {e}")
        print("Please check your BOT_TOKEN and internet connection")

if __name__ == "__main__":
    main()