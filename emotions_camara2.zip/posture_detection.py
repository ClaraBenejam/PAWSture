import cv2
import numpy as np
from ultralytics import YOLO
import math
import csv
import datetime
import time
from supabase import create_client, Client
import random

class PostureScorer:
    def __init__(self):
        self.model = YOLO('yolo11n-pose.pt')
        
        # Zones configuration
        self.zones = {
            'neck_lateral_bend': [5, 10, 20, 35],
            'neck_flexion': [9, 18, 30, 50],
            'shoulder_alignment': [5, 10, 20, 35],
            'arm_abduction': [13, 25, 45, 70],
        }
        
        # 5-level risk scale
        self.zone_risk = {
            0: "Very Low",
            1: "Low", 
            2: "Medium",
            3: "High",
            4: "Very High"
        }
        
        # Colors for 5 zones
        self.zone_colors = {
            0: (0, 255, 0),    # Green
            1: (0, 255, 255),  # Yellow
            2: (0, 165, 255),  # Orange
            3: (0, 0, 255),    # Red
            4: (128, 0, 128)   # Purple
        }
        
        # CSV configuration
        self.csv_file = f"posture_scores_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
        self.last_csv_time = 0
        self.csv_interval = 0.2
        
        # Supabase configuration
        self.SUPABASE_URL = "https://sunsfqthmwotlbfcgmay.supabase.co"
        self.SUPABASE_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InN1bnNmcXRobXdvdGxiZmNnbWF5Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjM0MDQwNjcsImV4cCI6MjA3ODk4MDA2N30.dLSgRjiiK4dDrYcwenp2RHBkMdQxYglficyyRripRN8"
        self.supabase = None
        
        # Alert system configuration
        self.last_alert_time = None
        self.alert_interval = 60  # 1 minuto entre alertas
        
        # Track continuous bad posture
        self.bad_posture_start_time = None
        self.continuous_bad_posture_threshold = 30  # 30 segundos de postura mala continua
        
        # Exercises for posture
        self.posture_exercises = [
    {
        "name": "Immediate Posture Correction",
        "description": "Quick adjustment to improve your current posture",
        "duration": "2 minutes",
        "type": "quick_correction",
        "steps": [
            "Sit upright with your back fully straight",
            "Push your shoulders back and down",
            "Align your ears with your shoulders",
            "Gently tuck your chin",
            "Take 3 deep breaths while maintaining posture"
        ],
        "emoji": "💺",
        "zones": [3, 4]
    },
    {
        "name": "Urgent Neck Stretch",
        "description": "Immediate relief for neck tension",
        "duration": "3 minutes",
        "type": "neck_relief",
        "steps": [
            "Completely relax your shoulders",
            "Gently turn your head to the right (15 seconds)",
            "Gently turn your head to the left (15 seconds)",
            "Tilt your right ear toward your shoulder (15 seconds)",
            "Tilt your left ear toward your shoulder (15 seconds)",
            "Repeat the full sequence"
        ],
        "emoji": "👤",
        "zones": [3, 4]
    },
    {
        "name": "Shoulder Realignment",
        "description": "Correct the position of your shoulders",
        "duration": "3 minutes",
        "type": "shoulder_correction",
        "steps": [
            "Place your hands on your shoulders",
            "Make large circles backward (10 reps)",
            "Make large circles forward (10 reps)",
            "Squeeze shoulder blades and hold 5 seconds (8 reps)",
            "Stretch arms out to the sides forming a T"
        ],
        "emoji": "💪",
        "zones": [3, 4]
    }
]

        self.urgent_breaks = [
    {
        "name": "URGENT BREAK - Stand Up and Move",
        "description": "IMMEDIATE INTERVENTION for CRITICAL posture",
        "duration": "5 minutes",
        "type": "urgent_break",
        "steps": [
            "STAND UP IMMEDIATELY!",
            "Walk around the room for 2 minutes",
            "Stretch arms toward the ceiling (20 seconds)",
            "Gently rotate torso (10 reps per side)",
            "Do gentle squats (8 reps)",
            "Take deep breaths before sitting back down"
        ],
        "emoji": "🚨",
        "zones": [4]
    }
]


        self.init_supabase()
        self.init_csv()

    def init_supabase(self):
        """Initialize Supabase client"""
        try:
            self.supabase = create_client(self.SUPABASE_URL, self.SUPABASE_KEY)
            print("✅ Supabase client initialized successfully")
        except Exception as e:
            print(f"❌ Error initializing Supabase: {e}")
            self.supabase = None

    def init_csv(self):
        """Initialize CSV file with headers"""
        headers = ['timestamp', 'overall_risk', 'overall_zone']
        for param in self.zones.keys():
            headers.extend([f'{param}_angle', f'{param}_zone', f'{param}_risk'])
        
        with open(self.csv_file, 'w', newline='', encoding='utf-8') as f:
            writer = csv.writer(f, delimiter=';')
            writer.writerow(headers)
        print(f"✅ CSV logging started: {self.csv_file}")

    def insert_posture_measurement(self, scores):
        """Insert posture measurement into Supabase"""
        if self.supabase is None:
            return False
        
        try:
            data = {
                "timestamp": datetime.datetime.now().isoformat(sep=" ", timespec="seconds"),
                "overall_risk": scores.get('overall', {}).get('risk', 'Unknown'),
                "overall_zone": scores.get('overall', {}).get('zone', 0),
            }
            
            for param in self.zones.keys():
                if param in scores:
                    data[f"{param}_angle"] = float(scores[param]['angle'])
                    data[f"{param}_zone"] = scores[param]['zone']
                    data[f"{param}_risk"] = scores[param]['risk']
                else:
                    data[f"{param}_angle"] = -1.0
                    data[f"{param}_zone"] = -1
                    data[f"{param}_risk"] = 'Not Detected'
            
            response = self.supabase.table("posture_sinid").insert(data).execute()
            return True
                
        except Exception as e:
            return False

    def check_posture_alerts(self, scores):
        """Check for all 4 types of posture alerts"""
        alerts = []
        
        if not scores or 'overall' not in scores:
            return alerts
        
        overall_zone = scores['overall']['zone']
        
        print(f"🔍 Analizando postura - Zona general: {overall_zone}")
        
        # 1. ALERTA PRINCIPAL: Zona de riesgo
        if overall_zone >= 4:
            alerts.append("🔴 **POSTURE ZONE 4** - VERY HIGH RISK detected")
        elif overall_zone >= 3:
            alerts.append("🟠 **POSTURE ZONE 3** - High risk detected")

        # 2. SPECIFIC ALERTS
        if 'neck_flexion' in scores and scores['neck_flexion']['zone'] >= 3:
            alerts.append("📱 **FORWARD NECK** - Excessive cervical flexion")

        if 'shoulder_alignment' in scores and scores['shoulder_alignment']['zone'] >= 3:
            alerts.append("⚖️ **MISALIGNED SHOULDERS** - Misalignment detected")

        if 'neck_lateral_bend' in scores and scores['neck_lateral_bend']['zone'] >= 3:
            alerts.append("↔️ **SIDE BENT NECK** - Excessive lateral tilt")

        
        # 3. Múltiples áreas en riesgo
        risk_params = sum(1 for param, data in scores.items() 
                         if param != 'overall' and data.get('zone', 0) >= 3)
        
        if risk_params >= 2:
            alerts.append("🔄 **MULTIPLE ISSUES** - Check your full posture")
        
        return alerts

    def generate_posture_recommendation(self, scores):
        """Generates recommendations BASED ONLY on POSTURE"""
        if not scores or 'overall' not in scores:
            return None
        
        overall_zone = scores['overall']['zone']
        
        # Verificar intervalo entre alertas
        current_time = datetime.datetime.now()
        if self.last_alert_time:
            time_diff = (current_time - self.last_alert_time).total_seconds()
            if time_diff < self.alert_interval:
                print(f"⏰ Waiting interval: {time_diff:.0f}/{self.alert_interval}s")
                return None
        
        print(f"🎯 Generating recommendation for zone {overall_zone}")
        
        # SELECCIONAR EJERCICIO SEGÚN ZONA
        if overall_zone >= 4:
            # Zona 4: Ejercicios urgentes
            available_exercises = [ex for ex in self.urgent_breaks if overall_zone in ex.get('zones', [])]
            if not available_exercises:
                available_exercises = self.urgent_breaks
            activity = random.choice(available_exercises)
            rec_type = "urgent_break"
            reason = f"CRITICAL POSTURE (Zone {overall_zone}) - Immediate intervention required"
            urgency = "CRITICAL"
            
        elif overall_zone >= 3:
            # Zona 3: Ejercicios correctivos
            available_exercises = [ex for ex in self.posture_exercises if overall_zone in ex.get('zones', [])]
            if not available_exercises:
                available_exercises = self.posture_exercises
            activity = random.choice(available_exercises)
            rec_type = "posture_correction"
            reason = f"Risky posture (Zone {overall_zone}) - Correction needed"
            urgency = "HIGH"
        else:
            print("✅ Posture correct, no recommendation generated")
            return None
        
        self.last_alert_time = current_time
        
        # Create recommendation
        recommendation_id = f"posture_{datetime.datetime.now().strftime('%Y%m%d%H%M%S')}_{random.randint(1000,9999)}"
        
        recommendation = {
            "id": recommendation_id,
            "recommendation_type": rec_type,
            "name": activity["name"],
            "description": activity["description"],
            "duration": activity["duration"],
            "reason": reason,
            "urgency": urgency,
            "steps": activity.get("steps", []),
            "emoji": activity.get("emoji", "💺"),
            "timestamp": current_time.strftime('%Y-%m-%d %H:%M:%S')
        }
        
        # Save to database
        self.insert_recommendation(recommendation)
        
        print(f"✅ Recomendation generated: {activity['name']}")
        return recommendation

    def insert_recommendation(self, recommendation):
        """Insert recommendation into Supabase"""
        if self.supabase is None:
            return False
        
        try:
            data = {
                "id": recommendation["id"],
                "recommendation_type": recommendation["recommendation_type"],
                "name": recommendation["name"],
                "description": recommendation["description"],
                "duration": recommendation["duration"],
                "reason": recommendation["reason"],
                "urgency": recommendation["urgency"],
                "steps": recommendation.get("steps", []),
                "emoji": recommendation.get("emoji", ""),
                "created_at": datetime.datetime.now().isoformat(sep=" ", timespec="seconds")
            }

            response = self.supabase.table("recommendations").insert(data).execute()
            print(f"💾 Recomendación guardada en BD: {recommendation['id']}")
            return True
                
        except Exception as e:
            print(f"❌ Error guardando recomendación: {e}")
            return False

    # MÉTODOS DE CÁLCULO DE POSTURA
    def calculate_neck_lateral_bend(self, left_ear, right_ear, left_shoulder, right_shoulder):
        shoulder_mid_y = (left_shoulder[1] + right_shoulder[1]) / 2
        left_ear_height = left_ear[1] - shoulder_mid_y
        right_ear_height = right_ear[1] - shoulder_mid_y
        ear_height_diff = abs(left_ear_height - right_ear_height)
        angle = min(ear_height_diff * 0.5, 50)
        return angle

    def calculate_shoulder_alignment(self, left_shoulder, right_shoulder):
        dx = right_shoulder[0] - left_shoulder[0]
        dy = right_shoulder[1] - left_shoulder[1]
        angle_rad = math.atan2(abs(dy), abs(dx))
        angle_deg = math.degrees(angle_rad)
        return angle_deg

    def calculate_vertical_angle(self, point1, point2):
        dx = point2[0] - point1[0]
        dy = point2[1] - point1[1]
        angle_rad = math.atan2(abs(dx), abs(dy))
        angle_deg = math.degrees(angle_rad)
        return angle_deg

    def calculate_neck_flexion(self, nose, left_shoulder, right_shoulder):
        shoulder_mid = (
            (left_shoulder[0] + right_shoulder[0]) / 2,
            (left_shoulder[1] + right_shoulder[1]) / 2
        )
        horizontal_distance = abs(nose[0] - shoulder_mid[0])
        vertical_distance = abs(nose[1] - shoulder_mid[1])
        if vertical_distance > 0:
            forward_ratio = horizontal_distance / vertical_distance
            return min(forward_ratio * 30, 60)
        return 0

    def get_zone(self, angle, parameter_name):
        thresholds = self.zones[parameter_name]
        if angle <= thresholds[0]: return 0
        elif angle <= thresholds[1]: return 1
        elif angle <= thresholds[2]: return 2
        elif angle <= thresholds[3]: return 3
        else: return 4

    def calculate_posture_scores(self, keypoints):
        if keypoints is None or len(keypoints) == 0:
            return {}
        
        kps = keypoints[0]
        scores = {}
        
        try:
            NOSE, LEFT_EAR, RIGHT_EAR = 0, 3, 4
            LEFT_SHOULDER, RIGHT_SHOULDER = 5, 6
            LEFT_ELBOW, RIGHT_ELBOW = 7, 8
            
            keypoint_data = {}
            for idx, kp in enumerate(kps):
                if kp[2] > 0.3:
                    keypoint_data[idx] = (float(kp[0]), float(kp[1]))
            
            # Neck lateral bend
            if all(k in keypoint_data for k in [LEFT_EAR, RIGHT_EAR, LEFT_SHOULDER, RIGHT_SHOULDER]):
                neck_angle = self.calculate_neck_lateral_bend(
                    keypoint_data[LEFT_EAR], keypoint_data[RIGHT_EAR],
                    keypoint_data[LEFT_SHOULDER], keypoint_data[RIGHT_SHOULDER]
                )
                scores['neck_lateral_bend'] = self.create_score(neck_angle, 'neck_lateral_bend')

            # Neck flexion
            if all(k in keypoint_data for k in [NOSE, LEFT_SHOULDER, RIGHT_SHOULDER]):
                neck_flexion_angle = self.calculate_neck_flexion(
                    keypoint_data[NOSE], keypoint_data[LEFT_SHOULDER], keypoint_data[RIGHT_SHOULDER]
                )
                scores['neck_flexion'] = self.create_score(neck_flexion_angle, 'neck_flexion')

            # Shoulder alignment
            if all(k in keypoint_data for k in [LEFT_SHOULDER, RIGHT_SHOULDER]):
                shoulder_angle = self.calculate_shoulder_alignment(
                    keypoint_data[LEFT_SHOULDER], keypoint_data[RIGHT_SHOULDER]
                )
                scores['shoulder_alignment'] = self.create_score(shoulder_angle, 'shoulder_alignment')

            # Arm abduction
            arm_angles = []
            if all(k in keypoint_data for k in [LEFT_SHOULDER, LEFT_ELBOW]):
                left_arm_angle = self.calculate_vertical_angle(
                    keypoint_data[LEFT_SHOULDER], keypoint_data[LEFT_ELBOW]
                )
                arm_angles.append(left_arm_angle)
                scores['left_arm_abduction'] = self.create_score(left_arm_angle, 'arm_abduction')

            if all(k in keypoint_data for k in [RIGHT_SHOULDER, RIGHT_ELBOW]):
                right_arm_angle = self.calculate_vertical_angle(
                    keypoint_data[RIGHT_SHOULDER], keypoint_data[RIGHT_ELBOW]
                )
                arm_angles.append(right_arm_angle)
                scores['right_arm_abduction'] = self.create_score(right_arm_angle, 'arm_abduction')

            if arm_angles:
                max_arm_angle = max(arm_angles)
                scores['arm_abduction'] = self.create_score(max_arm_angle, 'arm_abduction')

            # Overall score
            if scores:
                zones = [score['zone'] for score in scores.values() if score.get('zone') is not None]
                if zones:
                    max_zone = max(zones)
                    scores['overall'] = {
                        'zone': max_zone,
                        'risk': self.zone_risk[max_zone]
                    }

            return scores
            
        except Exception as e:
            return {}

    def create_score(self, angle, parameter_name):
        zone = self.get_zone(angle, parameter_name)
        return {
            'angle': angle,
            'zone': zone,
            'risk': self.zone_risk[zone]
        }

    def process_frame(self, frame):
        results = self.model(frame)
        annotated_frame = frame.copy()
        posture_scores = {}
        
        for result in results:
            if result.keypoints is not None:
                for keypoints in result.keypoints.data:
                    posture_scores = self.calculate_posture_scores([keypoints])
                    break
                break
        
        if posture_scores:
            self.export_measurements(posture_scores)
        
        return annotated_frame, posture_scores

    def export_measurements(self, scores):
        current_time = time.time()
        if current_time - self.last_csv_time < self.csv_interval:
            return
        
        self.last_csv_time = current_time
        self.export_to_csv(scores)
        
        # Solo enviar a Supabase cada 2 segundos para no saturar
        if current_time - getattr(self, 'last_supabase_time', 0) >= 2:
            self.last_supabase_time = current_time
            self.insert_posture_measurement(scores)

    def export_to_csv(self, scores):
        timestamp = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]
        
        row = [timestamp, scores.get('overall', {}).get('risk', 'Unknown'), scores.get('overall', {}).get('zone', 0)]
        
        for param in self.zones.keys():
            if param in scores:
                row.extend([
                    f"{scores[param]['angle']:.2f}",
                    scores[param]['zone'],
                    scores[param]['risk']
                ])
            else:
                row.extend(['-1', -1, 'Not Detected'])
        
        with open(self.csv_file, 'a', newline='', encoding='utf-8') as f:
            writer = csv.writer(f, delimiter=';')
            writer.writerow(row)

def main():
    # Initialize system
    scorer = PostureScorer()
    
    cap = cv2.VideoCapture(0)
    
    print("💺 PAWSture - Sistema de Detección de POSTURA")
    print("🔔 Alertas SOLO de POSTURA - Sin emociones")
    print("🎯 Detección: Zona 3-4 → Alertas inmediatas")
    print("⏰ Frecuencia: Chequeo cada 15 segundos")
    print("💾 Guardando en: Supabase + CSV")
    print("Press 'q' to quit")
    
    last_alert_check = 0
    alert_check_interval = 15  # Chequeo cada 15 segundos
    
    while True:
        ret, frame = cap.read()
        if not ret:
            break
        
        annotated_frame, scores = scorer.process_frame(frame)
        
        # Display posture information
        y_offset = 30
        
        if scores:
            overall = scores.get('overall', {})
            overall_zone = overall.get('zone', 0)
            overall_color = scorer.zone_colors[overall_zone]
            
            # Display overall posture
            cv2.putText(annotated_frame, f"Posture: {overall.get('risk', 'Unknown')} (Zone {overall_zone})", 
                       (10, y_offset), cv2.FONT_HERSHEY_SIMPLEX, 0.6, overall_color, 2)
            y_offset += 30
            
            # Display individual parameters
            for param, data in scores.items():
                if param != 'overall':
                    zone = data['zone']
                    color = scorer.zone_colors[zone]
                    
                    display_name = param.replace('_', ' ').title()
                    text = f"{display_name}: {data['risk']} (Zone {zone})"
                    
                    cv2.putText(annotated_frame, text, (10, y_offset), 
                               cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 1)
                    y_offset += 20
            
            # Check for alerts periodically
            current_time = time.time()
            if current_time - last_alert_check > alert_check_interval:
                last_alert_check = current_time
                
                alerts = scorer.check_posture_alerts(scores)
                if alerts:
                    print(f"\n🔔 ALERTAS POSTURALES DETECTADAS (Zona {overall_zone}):")
                    for alert in alerts:
                        print(f"   {alert}")
                    
                    # Generate recommendation
                    recommendation = scorer.generate_posture_recommendation(scores)
                    if recommendation:
                        print(f"🎯 RECOMENDACIÓN GENERADA: {recommendation['name']}")
                        print(f"📊 Razón: {recommendation['reason']}")
                        print(f"⚠️ Urgencia: {recommendation['urgency']}")
                        print("💾 Guardada en base de datos - Lista para Telegram")
        
        # Display status
        status_text = f"Posture Detection - Press Q to quit"
        cv2.putText(annotated_frame, status_text, (10, frame.shape[0] - 10), 
                   cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
        
        cv2.imshow('PAWSture - Detección de POSTURA (Press Q)', annotated_frame)
        
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break
    
    cap.release()
    cv2.destroyAllWindows()
    print(f"💾 CSV file saved: {scorer.csv_file}")
    print("👋 Sistema de postura apagado")

if __name__ == "__main__":
    main()