from pathlib import Path
import re
from datetime import datetime, timedelta
import requests
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ApplicationBuilder, CommandHandler, ContextTypes, CallbackQueryHandler
import asyncio
import os
import json
import sys

# Add the project root to Python path
REPO_ROOT = Path(__file__).resolve().parent
sys.path.append(str(REPO_ROOT))

# Import database functions
from cloud_db import insert_recommendation_response, get_recommendation_responses, get_user_response_stats

# ================================
# CONFIGURATION
# ================================

# Set with chat_ids stored in memory
CHAT_IDS = set()

# BOT_TOKEN: prefer environment variable for security
BOT_TOKEN = os.environ.get("BOT_TOKEN", "8151081242:AAGZCZucopD3f5FrQTrtw-JW6mAf5aUruCM")

# File to persist subscriber chat_ids
CHAT_STORE = REPO_ROOT / "posture_chat_ids.json"

# Default chat IDs (env): can be set as '12345,67890' for automatic messages
DEFAULT_CHAT_IDS = set()
env_default = os.environ.get("DEFAULT_CHAT_IDS")
if env_default:
    for part in env_default.split(","):
        part = part.strip()
        if part:
            try:
                DEFAULT_CHAT_IDS.add(int(part))
            except ValueError:
                DEFAULT_CHAT_IDS.add(part)

# ================================
# CHAT ID MANAGEMENT
# ================================

def load_persisted_chat_ids():
    """Loads chat_ids from `posture_chat_ids.json` (if it exists)"""
    try:
        if CHAT_STORE.exists():
            txt = CHAT_STORE.read_text(encoding="utf-8")
            arr = json.loads(txt)
            return set(arr)
    except Exception as e:
        print(f"Error loading persisted chat_ids: {e}")
    return set()

def save_persisted_chat_ids(chat_ids):
    """Saves chat_ids to `posture_chat_ids.json`"""
    try:
        CHAT_STORE.write_text(json.dumps(list(chat_ids), ensure_ascii=False), encoding="utf-8")
    except Exception as e:
        print(f"Error saving persisted chat_ids: {e}")

# Load persisted chat ids at startup
CHAT_IDS.update(load_persisted_chat_ids())

# ================================
# POSTURE ALERT SYSTEM
# ================================

def check_posture_alerts():
    """Checks for posture alert conditions from Supabase data"""
    alerts = []
    try:
        cloud_db_path = REPO_ROOT / "cloud_db.py"
        txt = cloud_db_path.read_text(encoding="utf-8")
        m_url = re.search(r"SUPABASE_URL\s*=\s*[\"'](.+?)[\"']", txt)
        m_key = re.search(r"SUPABASE_KEY\s*=\s*[\"'](.+?)[\"']", txt)
        if not m_url or not m_key:
            print("SUPABASE_URL/SUPABASE_KEY not found in cloud_db.py")
            return alerts
        SUPABASE_URL = m_url.group(1).strip()
        SUPABASE_KEY = m_key.group(1).strip()
    except Exception as e:
        print(f"Error reading cloud_db.py: {e}")
        return alerts

    headers = {
        "apikey": SUPABASE_KEY,
        "Authorization": f"Bearer {SUPABASE_KEY}",
        "Accept": "application/json",
    }

    base = SUPABASE_URL.rstrip("/") + "/rest/v1/posture"

    # 1) Check for high risk posture in last 2 minutes
    try:
        since = (datetime.now() - timedelta(minutes=2)).isoformat(sep=" ", timespec="seconds")
        # CORREGIDO: Usar timestamp en lugar de created_at
        url = f"{base}?select=overall_zone,overall_risk,timestamp&overall_zone=gte.3&timestamp=gte.{since}&order=timestamp.desc"
        print(f"🔍 Querying posture data: {url}")
        r = requests.get(url, headers=headers)
        r.raise_for_status()
        data = r.json()
        
        if isinstance(data, list) and data:
            high_risk_count = len(data)
            latest_posture = data[0]
            zone = latest_posture.get('overall_zone', 0)
            risk = latest_posture.get('overall_risk', 'Unknown')
            
            if zone >= 4:
                alerts.append(f"🔴 *CRITICAL POSTURE* - Zone {zone} ({risk}) detected")
            elif zone >= 3 and high_risk_count >= 3:
                alerts.append(f"🟠 *HIGH RISK POSTURE* - Zone {zone} persistent ({high_risk_count} readings)")
                
    except Exception as e:
        print(f"Error querying posture data in Supabase: {e}")

    # 2) Check for specific posture issues in last 5 minutes
    try:
        since = (datetime.now() - timedelta(minutes=5)).isoformat(timespec="seconds")
        # CORREGIDO: Usar timestamp en lugar de created_at
        url = f"{base}?select=neck_flexion_zone,shoulder_alignment_zone,neck_lateral_bend_zone&timestamp=gte.{since}&order=timestamp.desc&limit=10"
        print(f"🔍 Querying specific posture issues: {url}")
        r = requests.get(url, headers=headers)
        r.raise_for_status()
        data = r.json()
        
        if isinstance(data, list):
            # Check for neck flexion issues
            neck_flexion_issues = sum(1 for item in data if item.get('neck_flexion_zone', 0) >= 3)
            if neck_flexion_issues >= 5:
                alerts.append("📱 *EXCESSIVE NECK FLEXION* - Forward head posture detected")
            
            # Check for shoulder alignment issues
            shoulder_issues = sum(1 for item in data if item.get('shoulder_alignment_zone', 0) >= 3)
            if shoulder_issues >= 5:
                alerts.append("⚖️ *SHOULDER MISALIGNMENT* - Uneven shoulders detected")
            
            # Check for neck lateral bend issues
            neck_bend_issues = sum(1 for item in data if item.get('neck_lateral_bend_zone', 0) >= 3)
            if neck_bend_issues >= 5:
                alerts.append("↔️ *NECK TILT* - Head leaning to one side")
                
    except Exception as e:
        print(f"Error querying specific posture issues: {e}")

    return alerts

def get_latest_posture_recommendation():
    """Gets posture recommendations from the database"""
    try:
        cloud_db_path = REPO_ROOT / "cloud_db.py"
        txt = cloud_db_path.read_text(encoding="utf-8")
        m_url = re.search(r"SUPABASE_URL\s*=\s*[\"'](.+?)[\"']", txt)
        m_key = re.search(r"SUPABASE_KEY\s*=\s*[\"'](.+?)[\"']", txt)
        if not m_url or not m_key:
            print("SUPABASE_URL/SUPABASE_KEY not found in cloud_db.py")
            return None, None
        
        SUPABASE_URL = m_url.group(1).strip()
        SUPABASE_KEY = m_key.group(1).strip()
        
        headers = {
            "apikey": SUPABASE_KEY,
            "Authorization": f"Bearer {SUPABASE_KEY}",
            "Accept": "application/json",
        }

        # Get latest posture recommendation from database
        base = SUPABASE_URL.rstrip("/") + "/rest/v1/recommendations"
        since = (datetime.now() - timedelta(minutes=10)).isoformat(sep=" ", timespec="seconds")
        # CORREGIDO: Usar created_at para recommendations
        url = f"{base}?select=*&recommendation_type=in.(urgent_break,posture_correction)&created_at=gte.{since}&order=created_at.desc&limit=1"
        
        print(f"🔍 Querying recommendations: {url}")
        r = requests.get(url, headers=headers)
        r.raise_for_status()
        data = r.json()
        
        if isinstance(data, list) and data:
            recommendation = data[0]
            alerts = check_posture_alerts()
            message = format_posture_message(recommendation, alerts)
            return recommendation, message
            
    except Exception as e:
        print(f"Error getting posture recommendation: {e}")
    
    return None, None

def format_posture_message(recommendation, alerts=None):
    """Formats posture recommendation for Telegram"""
    if recommendation.get("urgency") == "critical":
        title = "🚨 URGENT POSTURE ALERT"
    else:
        title = "💺 POSTURE RECOMMENDATION"

    
    message = f"""
{title}

*{recommendation['name']}*
_{recommendation['description']}_

⏱️ *Duration:* {recommendation['duration']}
📊 *Reason:* {recommendation['reason']}
⚠️ *Urgency:* {recommendation.get('urgency', 'HIGH').upper()}

"""
    
    if alerts:
        message += "*🔔 Issues Detected:*\n"
        for alert in alerts:
            clean_alert = alert.replace('*', '')
            message += f"• {clean_alert}\n"
        message += "\n"
    
    message += "*📝 Steps to Follow:*\n"
    steps = recommendation.get('steps', [])
    if isinstance(steps, str):
        # Si steps es string, intentar convertir de JSON
        try:
            steps = json.loads(steps)
        except:
            steps = [steps]
    
    for i, step in enumerate(steps, 1):
        message += f"{i}. {step}\n"
    
    message += f"\n💡 Generated: {datetime.now().strftime('%H:%M')}_"
    
    return message

def create_posture_keyboard(recommendation_id):
    """Creates inline keyboard for posture recommendations"""
    keyboard = [
        [
            InlineKeyboardButton("✅ Accept", callback_data=f"accept_{recommendation_id}"),
            InlineKeyboardButton("⏸️ Postpone", callback_data=f"postpone_{recommendation_id}"),
        ],
        [
            InlineKeyboardButton("❌ Reject", callback_data=f"reject_{recommendation_id}"),
            InlineKeyboardButton("📊 Info", callback_data=f"info_{recommendation_id}"),
        ]
    ]
    return InlineKeyboardMarkup(keyboard)

# ================================
# TELEGRAM BOT HANDLERS
# ================================

async def posture_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Command /posture_start - Subscribe to posture alerts"""
    chat_id = update.message.chat_id
    CHAT_IDS.add(chat_id)
    save_persisted_chat_ids(CHAT_IDS)

    await update.message.reply_text(
    "💺 *PAWSture Posture Bot - System Active*\n\n"
    "✅ *You have subscribed to POSTURE alerts*\n"
    "📊 You will receive:\n"
    "   • High-risk posture alerts (Zone 3-4)\n"
    "   • Posture exercise recommendations\n"
    "   • Posture correction notifications\n\n"
    "⏰ *Frequency:* Checks every 2 minutes\n"
    "🔧 Use /posture_alerts to view current status\n"
    "💡 Use /posture_recommendation for manual check\n\n"
    "*Interactive Features:*\n"
    "✅ Accept - Start the posture exercise\n"
    "⏸️ Postpone - Reminder in 10 minutes\n"
    "❌ Reject - Decline the recommendation\n"
    "📊 Info - View posture benefits",
    parse_mode="Markdown"
    )

    print(f"✅ New posture subscriber: {chat_id}")


async def posture_alerts(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Command /posture_alerts - Current posture status"""
    alerts_list = check_posture_alerts()
    
    if not alerts_list:
        await update.message.reply_text(
            "🟢 *Posture status:* No active alerts\n"
            "Your posture is being monitored...",
            parse_mode="Markdown"

        )
    else:
        msg ="📢 *Active Posture Alerts:*\n\n" + "\n".join(alerts_list)
        await update.message.reply_text(msg, parse_mode="HTML")

async def posture_recommendation(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Command /posture_recommendation - Manual posture check"""
    recommendation, message = get_latest_posture_recommendation()
    
    if recommendation and message:
        keyboard = create_posture_keyboard(recommendation['id'])
        await update.message.reply_text(
            message,
            parse_mode="HTML",
            reply_markup=keyboard
        )
    else:
        await update.message.reply_text(
        "💚 *Optimal posture:* No interventions are needed at this moment.\n"
        "Your posture is within normal parameters.",
        parse_mode="HTML"
)


async def posture_stats(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Command /posture_stats - Posture response statistics"""
    user_id = update.message.from_user.id
    username = update.message.from_user.username or f"user_{user_id}"
    
    try:
        user_stats = get_user_response_stats(user_id, days=30)
        
        total_responses = sum(user_stats.values())
        
        if total_responses == 0:
            await update.message.reply_text(
                "📊 *Tus Estadísticas Posturales*\n\n"
                "Aún no has respondido a recomendaciones posturales.\n\n"
                "Cuando recibas recomendaciones, puedes:\n"
                "✅ Aceptar - Iniciar el ejercicio\n"
                "⏸️ Posponer - Recordar más tarde\n"
                "❌ Rechazar - Declinar por ahora",
                parse_mode="Markdown"
            )
            return
        
        acceptance_rate = (user_stats.get('accept', 0) / total_responses) * 100
        
        message = f"""
📊 *Tus Estadísticas Posturales (30 días)*

*Resumen de Respuestas:*
✅ Aceptadas: {user_stats.get('accept', 0)}
⏸️ Pospuestas: {user_stats.get('postpone', 0)}
❌ Rechazadas: {user_stats.get('reject', 0)}
📈 Tasa de Aceptación: {acceptance_rate:.1f}%

*Beneficios de los ejercicios posturales:*
- Reducen dolor de espalda y cuello
- Mejoran la circulación sanguínea
- Aumentan la productividad
- Previenen lesiones crónicas

¡Sigue cuidando tu postura! 🎉
"""
        await update.message.reply_text(message, parse_mode="HTML")
        
    except Exception as e:
        print(f"Error in posture_stats command: {e}")
        await update.message.reply_text(
            "❌ Error obteniendo tus estadísticas. Intenta más tarde.",
            parse_mode="HTML"
        )

# ================================
# RESPONSE HANDLERS
# ================================

async def handle_posture_response(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handles responses to posture recommendations"""
    query = update.callback_query
    await query.answer()
    
    user_id = query.from_user.id
    username = query.from_user.username or f"user_{user_id}"
    callback_data = query.data
    
    parts = callback_data.split('_')
    if len(parts) < 2:
        await query.edit_message_text("❌ Formato de respuesta inválido.")
        return
        
    action = parts[0]
    recommendation_id = '_'.join(parts[1:])
    
    if action in ['accept', 'postpone', 'reject']:
        db_result = insert_recommendation_response(
            recommendation_id=recommendation_id,
            user_id=user_id,
            username=username,
            response=action
        )
        
        if db_result:
            response_texts = {
                'accept': '✅ ACEPTASTE la recomendación postural',
                'postpone': '⏸️ POSPUSISTE la recomendación postural', 
                'reject': '❌ RECHAZASTE la recomendación postural'
            }
            
            new_text = query.message.text + f"\n\n{response_texts[action]} por @{username}"
            
            await query.edit_message_text(
                text=new_text,
                parse_mode="HTML",
                reply_markup=None
            )
            
            print(f"Usuario {user_id} ({username}) {action} recomendación postural {recommendation_id}")
            
        else:
            await query.edit_message_text(
                text="⚠️ Error guardando tu respuesta. Intenta nuevamente.",
                parse_mode="HTML"
            )
    
    elif action == 'info':
        await show_posture_info(recommendation_id, query)

async def show_posture_info(recommendation_id, query):
    """Shows posture benefits information"""
    info_text = """
📊 *Beneficios de la Corrección Postural*

*Estadísticas de Salud:*
• 80% reducción en dolor lumbar
• 45% mejora en capacidad respiratoria  
• 30% aumento en productividad
• 60% menos fatiga visual

*Beneficios a Largo Plazo:*
- Previene hernias discales
- Reduce dolores de cabeza tensionales
- Mejora la digestión
- Aumenta la confianza

¡Tu postura afecta toda tu salud! 💚
"""
    await query.edit_message_text(
        text=info_text,
        parse_mode="HTML"
    )

# ================================
# PERIODIC TASKS
# ================================

async def send_posture_alerts_periodically(context: ContextTypes.DEFAULT_TYPE):
    """Sends posture alerts and recommendations periodically"""
    print(f"🔍 Checking posture alerts at {datetime.now().strftime('%H:%M:%S')}")
    
    # Get posture alerts
    alerts_list = check_posture_alerts()
    
    # Get posture recommendation
    recommendation, message = get_latest_posture_recommendation()
    
    # Build recipients list
    recipients = set(CHAT_IDS) | set(DEFAULT_CHAT_IDS)
    
    if not recipients:
        print("⚠️ No recipients for posture alerts - use /posture_start to subscribe")
        return
    
    # Send alerts if any
    if alerts_list:
        alert_message = "📢 *Alertas Posturales Detectadas:*\n\n" + "\n".join(alerts_list)
        
        for chat_id in recipients:
            try:
                await context.bot.send_message(
                    chat_id=chat_id, 
                    text=alert_message, 
                    parse_mode="HTML"
                )
                print(f"✅ Posture alert sent to {chat_id}")
            except Exception as e:
                print(f"Error sending posture alert to {chat_id}: {e}")
    
    # Send recommendation if available
    if recommendation and message:
        try:
            keyboard = create_posture_keyboard(recommendation['id'])
            
            for chat_id in recipients:
                try:
                    await context.bot.send_message(
                        chat_id=chat_id,
                        text=message,
                        parse_mode="HTML",
                        reply_markup=keyboard
                    )
                    print(f"✅ Posture recommendation sent to {chat_id}")
                except Exception as e:
                    print(f"Error sending posture recommendation to {chat_id}: {e}")
                    
        except Exception as e:
            print(f"Error processing posture recommendation: {e}")
    
    # Log status
    if not alerts_list and not recommendation:
        print("🟢 No posture alerts or recommendations to send")

# ================================
# MAIN FUNCTION
# ================================

def main():
    """Main function to start the posture bot"""
    if not BOT_TOKEN:
        print("❌ ERROR: BOT_TOKEN environment variable is required")
        return
    
    try:
        # Create application
        app = ApplicationBuilder().token(BOT_TOKEN).build()
        
        # Add command handlers - USING POSTURE COMMANDS
        app.add_handler(CommandHandler("posture_start", posture_start))
        app.add_handler(CommandHandler("posture_alerts", posture_alerts))
        app.add_handler(CommandHandler("posture_recommendation", posture_recommendation))
        app.add_handler(CommandHandler("posture_stats", posture_stats))
        
        # Add callback query handler for posture responses
        app.add_handler(CallbackQueryHandler(handle_posture_response))
        
        # Schedule periodic tasks for posture (every 2 minutes)
        app.job_queue.run_repeating(send_posture_alerts_periodically, interval=120, first=10)
        
        # Startup message
        print("💺 PAWSture POSTURE Bot starting...")
        print("📊 Posture alert system: ACTIVE")
        print("💡 Posture recommendation system: ACTIVE") 
        print("⏰ Checking posture every 2 minutes")
        print(f"👥 Subscribed users: {len(CHAT_IDS)}")
        print(f"📍 Default recipients: {len(DEFAULT_CHAT_IDS)}")
        print("🔧 Bot commands: /posture_start, /posture_alerts, /posture_recommendation, /posture_stats")
        print("🎯 Ready to receive posture messages...")
        print("⚠️ Remember to use /posture_start in Telegram to subscribe!")
        
        # Start polling
        app.run_polling()
        
    except Exception as e:
        print(f"❌ Failed to start posture bot: {e}")
        print("Please check your BOT_TOKEN and internet connection")

if __name__ == "__main__":
    main()