from telegram import Bot
from pathlib import Path

BOT_TOKEN = "8151081242:AAGZCZucopD3f5FrQTrtw-JW6mAf5aUruCM"
CHAT_IDS = set()  # Igual que en alertas.py

bot = Bot(token=BOT_TOKEN)

async def send_recommendation_to_telegram(recommendation: dict):
    """
    Envía la recomendación al bot para todos los usuarios suscritos.
    """
    if not CHAT_IDS:
        print("⚠️ No hay usuarios suscritos a Telegram")
        return

    message = (
        f"💡 *Nueva recomendación*\n\n"
        f"*Actividad:* {recommendation['name']}\n"
        f"*Tipo:* {recommendation['type']}\n"
        f"*Razón:* {recommendation['reason']}\n\n"
        "Responde con /aceptar o /rechazar"
    )

    for chat_id in CHAT_IDS:
        try:
            await bot.send_message(chat_id=chat_id, text=message, parse_mode="Markdown")
        except Exception as e:
            print(f"❌ Error enviando recomendación a {chat_id}: {e}")
