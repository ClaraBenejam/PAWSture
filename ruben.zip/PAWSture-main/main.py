import sys
from pathlib import Path

# Agregar la carpeta padre (ruben/) al path de búsqueda de Python
sys.path.append(str(Path(__file__).resolve().parent.parent))

# Ahora sí podemos importar telegram_helper
from telegram_helper import send_recommendation_to_telegram, CHAT_IDS

import cv2
from datetime import datetime, timedelta
from emotion_detector import analyze_frame, stress_from_emotion
from cloud_db import insert_emotion, insert_recommendation, log_user_response
from recommendation_system import SimpleRecommendationSystem
import asyncio

NEGATIVE_EMOTIONS = {"angry", "fear", "disgust", "sad", "neutral"}
STRESS_TIME_THRESHOLD = 5  # segundos

class RecommendationManager:
    def __init__(self):
        self.recommendation_system = SimpleRecommendationSystem()
        self.last_recommendation_time = None
        self.recommendation_interval = timedelta(minutes=2)  # REDUCIDO a 2 minutos para testing
        self.current_recommendation = None
        self.recommendation_display_time = None
        self.recommendation_timeout = timedelta(seconds=30)  # 30 segundos para responder
        
    def should_recommend(self, emotion, stress_level, risk_score):
        now = datetime.now()

        # Evitar recomendación si hay una activa
        if self.current_recommendation is not None:
            if self.recommendation_display_time and (
                now - self.recommendation_display_time > self.recommendation_timeout
            ):
                self.clear_recommendation()
                return True
            return False

        # Esperar intervalo mínimo
        if self.last_recommendation_time is not None:
            if now - self.last_recommendation_time < self.recommendation_interval:
                return False

        # Estrés alto = prioridad máxima
        if stress_level == "alto":
            return True

        # Riesgo alto
        if risk_score >= 0.7:
            return True

        # Emociones negativas mantenidas
        if emotion in ["sad", "angry", "fear", "disgust"] and risk_score >= 0.4:
            return True

        # Caso contrario → No recomendar
        return False


    def get_recommendation(self, emotion: str, stress_level: str):
        try:
            recommendation = self.recommendation_system.recommend(emotion, stress_level)
            
            # Verificación de claves
            required_keys = ['name', 'type', 'reason']
            for key in required_keys:
                if key not in recommendation:
                    print(f"⚠️ Advertencia: Recomendación falta clave '{key}'")
                    return self.get_fallback_recommendation(stress_level)

            self.last_recommendation_time = datetime.now()
            self.current_recommendation = recommendation
            self.recommendation_display_time = datetime.now()
            return recommendation
        except Exception as e:
            print(f"❌ Error generando recomendación: {e}")
            return self.get_fallback_recommendation(stress_level)

    def get_fallback_recommendation(self, stress_level: str):
        """Recomendación de respaldo segura"""
        return {
            'name': 'Respiración profunda',
            'type': 'breathing',
            'duration_minutes': 3,
            'description': 'Técnica básica de respiración para reducir estrés',
            'reason': 'Recomendación de seguridad'
        }
    
    def clear_recommendation(self):
        self.current_recommendation = None
        self.recommendation_display_time = None
        self.last_recommendation_time = None  # 🔥 IMPORTANTE
        print("🔄 Listo para nueva recomendación")

# Después de la definición de RecommendationManager
recommendation_manager = RecommendationManager()

def main():
    cap = cv2.VideoCapture(0, cv2.CAP_DSHOW)
    if not cap.isOpened():
        print("No se pudo abrir la cámara")
        return
    
    currently_negative = False
    negative_start_time = None
    last_emotion = None
    last_stress_level = None

    print("🚀 Sistema PAWSture iniciado")
    print("   - Detectar emociones y estrés en tiempo real")
    print("   - Recomendaciones personalizadas cada 2 minutos")
    print("   - Presiona 'A' para ACEPTAR recomendación")
    print("   - Presiona 'R' para RECHAZAR recomendación") 
    print("   - Presiona 'Q' para SALIR")

    while True:
        ret, frame = cap.read()
        if not ret:
            print("No se pudo leer un frame de la cámara")
            break

        frame = cv2.flip(frame, 1)
        now = datetime.now()
        results = analyze_frame(frame)

        # Variables para el estado actual
        current_emotion = None
        current_stress_level = None
        current_stress_score = 0.0

        for r in results:
            x, y, w, h = r["box"]
            emotion = r["emotion"]
            gender = r["gender"]

            base_score, base_level = stress_from_emotion(emotion)
            em_lower = emotion.lower()

            if em_lower in NEGATIVE_EMOTIONS:
                if not currently_negative:
                    currently_negative = True
                    negative_start_time = now

                elapsed = 0
                if negative_start_time is not None:
                    elapsed = (now - negative_start_time).total_seconds()

                if elapsed < STRESS_TIME_THRESHOLD:
                    stress_score = 0.0
                    stress_level = "bajo"
                elif elapsed < STRESS_TIME_THRESHOLD * 2:
                    stress_score = base_score / 2
                    stress_level = "medio"
                else:
                    stress_score = base_score
                    stress_level = base_level
            else:
                currently_negative = False
                negative_start_time = None
                stress_score = 0.0
                stress_level = "bajo"

            # Guardar estado actual para usar en recomendaciones
            current_emotion = emotion
            current_stress_level = stress_level
            current_stress_score = stress_score

            # Insertar datos de emociones
            insert_emotion(emotion, gender, stress_score, stress_level)

            # DIBUJAR INFORMACIÓN EN EL FRAME
            cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 255, 0), 2)

            text1 = f"{emotion} - {gender}"
            cv2.putText(frame, text1, (x, y - 25),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 0, 255), 2)

            text2 = f"stress: {stress_level} ({stress_score:.1f})"
            cv2.putText(frame, text2, (x, y - 5),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 0), 2)

        # VERIFICAR Y GENERAR RECOMENDACIONES (solo si tenemos datos actuales)
        if current_emotion and current_stress_level:
            risk_score = current_stress_score / 10  # normaliza a 0-1
            
            if recommendation_manager.should_recommend(current_emotion, current_stress_level, risk_score):
                recommendation = recommendation_manager.get_recommendation(current_emotion, current_stress_level)

                # Guardar la recomendación en la base de datos
                try:
                    insert_recommendation(
                        emotion=current_emotion,
                        stress_level=current_stress_level,
                        activity_name=recommendation['name'],
                        activity_type=recommendation['type'],
                        reason=recommendation['reason']
                    )
                    asyncio.create_task(send_recommendation_to_telegram(recommendation))

                    print(f"✅ NUEVA RECOMENDACIÓN: {recommendation['name']}")
                    print(f"   📝 Razón: {recommendation['reason']}")
                    print("   🎯 Presiona 'A' para ACEPTAR o 'R' para RECHAZAR")
                except Exception as e:
                    print(f"❌ Error guardando recomendación: {e}")

        # MOSTRAR RECOMENDACIÓN ACTUAL
        if recommendation_manager.current_recommendation:
            rec = recommendation_manager.current_recommendation
            
            # Calcular tiempo restante
            if recommendation_manager.recommendation_display_time:
                elapsed = now - recommendation_manager.recommendation_display_time
                time_left = recommendation_manager.recommendation_timeout - elapsed
                seconds_left = max(0, int(time_left.total_seconds()))
            else:
                seconds_left = 30
            
            # Fondo semitransparente para mejor legibilidad
            overlay = frame.copy()
            cv2.rectangle(overlay, (0, 0), (600, 120), (0, 0, 0), -1)
            cv2.addWeighted(overlay, 0.6, frame, 0.4, 0, frame)
            
            text3 = f"RECOMENDACION: {rec['name']}"
            cv2.putText(frame, text3, (10, 25),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)
            
            text4 = f"Razon: {rec['reason']}"
            cv2.putText(frame, text4, (10, 50),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
            
            text5 = f"Tiempo: {seconds_left}s - A:ACEPTAR  R:RECHazar"
            cv2.putText(frame, text5, (10, 80),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 255), 2)
        else:
            # Mostrar estado del sistema
            status_text = f"Sistema activo - Proxima recomendacion en max {recommendation_manager.recommendation_interval.seconds//60} min"
            cv2.putText(frame, status_text, (10, 30),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 1)

        # INTERACCIÓN CON TECLADO
        key = cv2.waitKey(1) & 0xFF
        
        if key == ord('a') and recommendation_manager.current_recommendation:
            rec = recommendation_manager.current_recommendation
            success = log_user_response(
                activity_name=rec['name'],
                activity_type=rec['type'],
                accepted=True
    )
            if success:
                print(f"🎉 RECOMENDACIÓN ACEPTADA: {rec['name']}")
            else:
                print(f"⚠️ Error guardando aceptación")
            recommendation_manager.clear_recommendation()
    
        elif key == ord('r') and recommendation_manager.current_recommendation:
            rec = recommendation_manager.current_recommendation
            success = log_user_response(
                activity_name=rec['name'],
                activity_type=rec['type'],
                accepted=False
                )
            if success:
                print(f"❌ RECOMENDACIÓN RECHAZADA: {rec['name']}")
            else:
                print(f"⚠️ Error guardando rechazo")
            recommendation_manager.clear_recommendation()


        cv2.imshow("PAWSture - Sistema de Recomendaciones Inteligentes", frame)

        if key == ord('q'):
            print("👋 Saliendo del sistema...")
            break

    cap.release()
    cv2.destroyAllWindows()

if __name__ == "__main__":
    main()