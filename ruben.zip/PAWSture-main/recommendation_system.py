# recommendation_system.py
import numpy as np
from sklearn.neural_network import MLPClassifier
from sklearn.preprocessing import LabelEncoder
import pandas as pd
from datetime import datetime
import random

class SimpleRecommendationSystem:
    def __init__(self):
        self.mlp = MLPClassifier(hidden_layer_sizes=(64, 32), random_state=42)
        self.emotion_encoder = LabelEncoder()
        self.stress_encoder = LabelEncoder()
        self.activity_encoder = LabelEncoder()
        self.is_trained = False
        
    def prepare_training_data(self):
        """Datos de entrenamiento inicial basados en reglas simples"""
        emotions = ['angry', 'fear', 'disgust', 'sad', 'neutral', 'surprise', 'happy']
        stress_levels = ['bajo', 'medio', 'alto']
        
        # Mapeo de reglas simples basado en tu estado del arte
        training_data = []
        
        # Estrés alto + emociones negativas -> actividades relajantes
        for emotion in ['angry', 'fear', 'disgust', 'sad']:
            training_data.append({
                'emotion': emotion,
                'stress_level': 'alto',
                'activity_type': 'breathing'
            })
        
        # Estrés medio + neutral -> descansos activos
        training_data.append({
            'emotion': 'neutral',
            'stress_level': 'medio', 
            'activity_type': 'break'
        })
        
        # Cualquier estado -> estiramientos preventivos
        for emotion in emotions:
            for stress in stress_levels:
                training_data.append({
                    'emotion': emotion,
                    'stress_level': stress,
                    'activity_type': 'stretch'
                })
        
        return pd.DataFrame(training_data)
    
    def train(self):
        """Entrenar el modelo MLP"""
        df = self.prepare_training_data()
        
        # Codificar características
        X_emotion = self.emotion_encoder.fit_transform(df['emotion'])
        X_stress = self.stress_encoder.fit_transform(df['stress_level'])
        
        # Combinar características
        X = np.column_stack([X_emotion, X_stress])
        y = self.activity_encoder.fit_transform(df['activity_type'])
        
        # Entrenar modelo
        self.mlp.fit(X, y)
        self.is_trained = True
        
    def recommend(self, emotion, stress_level, user_history=None):
        if user_history is None:
            user_history = []

        # 1. Evitar actividades rechazadas (no se usará ahora)
        avoided_types = [h['activity_type'] for h in user_history if not h['accepted']]

        # 2. Obtener tipo con el MLP
        activity_type = self.predict_type(emotion, stress_level)

        # 3. Si activity_type está en evitados, escoger otro (no aplica aquí)
        if activity_type in avoided_types:
            activity_type = self.get_alternative(activity_type)

        # 4. Seleccionar actividad específica
        return self.select_specific_activity(activity_type, emotion, stress_level)
    
    def predict_type(self, emotion: str, stress_level: str):
        if not self.is_trained:
            self.train()  # asegúrate de que el MLP esté entrenado

        # Codificar características
        X_em = self.emotion_encoder.transform([emotion])
        X_st = self.stress_encoder.transform([stress_level])
        X = np.column_stack([X_em, X_st])

        # Predecir
        y_pred = self.mlp.predict(X)
        activity_type = self.activity_encoder.inverse_transform(y_pred)[0]
        return activity_type

    def get_alternative(self, activity_type):
        # Por ahora, simplemente devolvemos el mismo tipo
        # Podrías implementar lógica para alternativas aquí
        return activity_type
    
    def get_fallback_recommendation(self, stress_level: str):
        """Recomendación por defecto si el modelo falla"""
        if stress_level == 'alto':
            return {
                'name': 'Respiración profunda',
                'type': 'breathing',
                'duration_minutes': 3,
                'description': 'Técnica de respiración 4-7-8 para reducir estrés',
                'reason': 'Alto nivel de estrés detectado'
            }
        else:
            return {
                'name': 'Estiramiento de cuello',
                'type': 'stretch',
                'duration_minutes': 2,
                'description': 'Giros suaves de cuello para aliviar tensión',
                'reason': 'Prevención de tensión muscular'
            }
    
    def select_specific_activity(self, activity_type: str, emotion: str, stress_level: str):
        """Seleccionar actividad específica basada en el tipo"""
        activities = {
            'breathing': [
                {
                    'name': 'Respiración 4-7-8',
                    'type': 'breathing',
                    'duration_minutes': 3,
                    'description': 'Inhala 4 segundos, mantén 7, exhala 8. Repite 5 veces.',
                    'reason': f'Perfecto para reducir {stress_level} nivel de estrés'
                },
                {
                    'name': 'Respiración diafragmática',
                    'type': 'breathing',
                    'duration_minutes': 4,
                    'description': 'Respiración profunda desde el abdomen para calmar el sistema nervioso',
                    'reason': f'Ideal para manejar {stress_level} nivel de estrés'
                }
            ],
            'stretch': [
                {
                    'name': 'Estiramiento cervical',
                    'type': 'stretch',
                    'duration_minutes': 2,
                    'description': 'Inclina cabeza suavemente hacia cada hombro.',
                    'reason': 'Alivia tensión del cuello por postura'
                },
                {
                    'name': 'Estiramiento de hombros',
                    'type': 'stretch',
                    'duration_minutes': 3,
                    'description': 'Rota hombros hacia adelante y atrás, luego estira brazos',
                    'reason': 'Libera tensión acumulada en hombros'
                }
            ],
            'break': [
                {
                    'name': 'Pausa activa',
                    'type': 'break',
                    'duration_minutes': 5,
                    'description': 'Levántate y camina 2 minutos, estira brazos.',
                    'reason': 'Descanso preventivo recomendado'
                },
                {
                    'name': 'Micro-descanso',
                    'type': 'break',
                    'duration_minutes': 2,
                    'description': 'Levántate, mira por la ventana y respira profundamente',
                    'reason': 'Descanso rápido para resetear la mente'
                }
            ]
        }
        
        # Asegurarnos de que siempre devolvemos una actividad con 'type'
        available_activities = activities.get(activity_type, [self.get_fallback_recommendation(stress_level)])
        selected_activity = random.choice(available_activities)
        
        # Verificación de seguridad
        if 'type' not in selected_activity:
            selected_activity['type'] = activity_type
            
        # CORRECCIÓN IMPORTANTE: Quita la coma al final del return
        return selected_activity  # ← Sin coma aquí